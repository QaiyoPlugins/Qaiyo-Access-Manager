<?php
/**
 * Plugin Name: Qaiyo Access Manager
 * Plugin URI: https://qaiyo-plugins.com/qaiyo-access-manager
 * Description: Extend WordPress permission management: control which plugins and custom post types each role or individual user can see and manage.
 * Version: 1.1.0
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Author: Qaiyo
 * Author URI: https://qaiyo-plugins.com
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: qaiyo-access-manager
 * Domain Path: /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'QAIYO_ACCESS_MANAGER_VERSION', '1.1.0' );
define( 'QAIYO_ACCESS_MANAGER_PLUGIN_FILE', __FILE__ );
define( 'QAIYO_ACCESS_MANAGER_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'QAIYO_ACCESS_MANAGER_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'QAIYO_ACCESS_MANAGER_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

require_once QAIYO_ACCESS_MANAGER_PLUGIN_DIR . 'includes/class-qam-brand-menu.php';
require_once QAIYO_ACCESS_MANAGER_PLUGIN_DIR . 'includes/class-qam-options.php';
require_once QAIYO_ACCESS_MANAGER_PLUGIN_DIR . 'includes/class-qam-shortcodes.php';
require_once QAIYO_ACCESS_MANAGER_PLUGIN_DIR . 'includes/class-qam-login-redirect.php';
require_once QAIYO_ACCESS_MANAGER_PLUGIN_DIR . 'includes/class-qam-admin-bar.php';
require_once QAIYO_ACCESS_MANAGER_PLUGIN_DIR . 'includes/class-qam-update-permissions.php';
require_once QAIYO_ACCESS_MANAGER_PLUGIN_DIR . 'includes/class-qam-capabilities-viewer.php';
require_once QAIYO_ACCESS_MANAGER_PLUGIN_DIR . 'includes/class-qam-dashboard-widgets.php';
require_once QAIYO_ACCESS_MANAGER_PLUGIN_DIR . 'includes/class-qam-ecosystem.php';
require_once QAIYO_ACCESS_MANAGER_PLUGIN_DIR . 'includes/class-qam-pro-teaser.php';

// Traits split out of the main class (loaded before the class that uses them).
require_once QAIYO_ACCESS_MANAGER_PLUGIN_DIR . 'includes/trait-qam-enforcement.php';
require_once QAIYO_ACCESS_MANAGER_PLUGIN_DIR . 'includes/trait-qam-render.php';

if ( class_exists( 'Qaiyo_Access_Manager_Brand_Menu' ) ) {
	Qaiyo_Access_Manager_Brand_Menu::init();
	Qaiyo_Access_Manager_Brand_Menu::register_plugin_slug( 'qaiyo-access-manager' );
}

// Free behavior modules.
Qaiyo_Access_Manager_Options::init();
Qaiyo_Access_Manager_Shortcodes::init();
Qaiyo_Access_Manager_Login_Redirect::init();
Qaiyo_Access_Manager_Admin_Bar::init();
Qaiyo_Access_Manager_Update_Permissions::init();
Qaiyo_Access_Manager_Dashboard_Widgets::init();
Qaiyo_Access_Manager_Ecosystem::init();
Qaiyo_Access_Manager_Pro_Teaser::init();

final class Qaiyo_Access_Manager {

	use Qaiyo_Access_Manager_Enforcement;
	use Qaiyo_Access_Manager_Render;

	private static $instance = null;
	private $option_cache = array();
	private $menu_owner_cache = array();

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );

		add_action( 'wp_ajax_wpam_save_access', array( $this, 'ajax_save_access' ) );
		add_action( 'wp_ajax_wpam_search_users', array( $this, 'ajax_search_users' ) );
		add_action( 'wp_ajax_wpam_export', array( $this, 'ajax_export' ) );
		add_action( 'wp_ajax_wpam_import', array( $this, 'ajax_import' ) );
		add_action( 'wp_ajax_wpam_set_delete_data', array( $this, 'ajax_set_delete_data' ) );

		add_action( 'wp_dashboard_setup', array( $this, 'register_dashboard_widget' ) );

		add_filter( 'all_plugins', array( $this, 'filter_plugins_list' ) );
		add_filter( 'plugin_action_links', array( $this, 'filter_plugin_action_links' ), 10, 4 );
		// Runs last so every plugin (and Pro's menu reorder at 9999) has registered first.
		add_action( 'admin_menu', array( $this, 'enforce_restricted_plugin_pages' ), PHP_INT_MAX );

		add_action( 'admin_menu', array( $this, 'filter_cpt_admin_menus' ), 999 );
		add_filter( 'map_meta_cap', array( $this, 'filter_cpt_meta_caps' ), 10, 4 );
		add_filter( 'rest_pre_dispatch', array( $this, 'filter_cpt_rest_access' ), 10, 3 );
		add_action( 'pre_get_posts', array( $this, 'filter_cpt_queries' ) );
		add_action( 'template_redirect', array( $this, 'filter_cpt_frontend_access' ) );

		add_action( 'admin_notices', array( $this, 'restricted_notice' ) );
	}

	// =========================================================================
	// CORE HELPERS
	// =========================================================================

	private function get_option_cached( $key, $default = array() ) {
		if ( ! isset( $this->option_cache[ $key ] ) ) {
			$this->option_cache[ $key ] = get_option( $key, $default );
		}
		return $this->option_cache[ $key ];
	}

	private function clear_option_cache() {
		$this->option_cache = array();
	}

	private function get_plugin_rules() {
		return $this->get_option_cached( 'wpam_plugin_role_rules', array() );
	}

	private function get_cpt_rules() {
		return $this->get_option_cached( 'wpam_cpt_role_rules', array() );
	}

	private function get_user_plugin_rules() {
		return $this->get_option_cached( 'wpam_plugin_user_rules', array() );
	}

	private function get_user_cpt_rules() {
		return $this->get_option_cached( 'wpam_cpt_user_rules', array() );
	}

	private function get_editable_roles() {
		$roles    = wp_roles()->roles;
		$editable = array();
		foreach ( $roles as $slug => $role ) {
			if ( 'administrator' === $slug ) {
				continue;
			}
			$editable[ $slug ] = $role;
		}
		return $editable;
	}

	private function get_manageable_plugins() {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$all = get_plugins();
		unset( $all[ QAIYO_ACCESS_MANAGER_PLUGIN_BASENAME ] );
		return $all;
	}

	private function get_custom_post_types() {
		$builtin = array(
			'post', 'page', 'attachment', 'revision', 'nav_menu_item',
			'custom_css', 'customize_changeset', 'oembed_cache', 'user_request',
			'wp_block', 'wp_template', 'wp_template_part', 'wp_global_styles',
			'wp_navigation', 'wp_font_family', 'wp_font_face',
			// WPML
			'wp_translation', 'wpml_translation_job',
			// Polylang
			'polylang_mo',
			// TranslatePress
			'trp_translation', 'trp_language',
		);
		$all    = get_post_types( array(), 'objects' );
		$custom = array();
		foreach ( $all as $slug => $obj ) {
			if ( in_array( $slug, $builtin, true ) ) {
				continue;
			}
			if ( ! $obj->public && ! $obj->show_ui ) {
				continue;
			}
			$custom[ $slug ] = $obj;
		}
		return $custom;
	}

	// =========================================================================
	// ACCESS CHECK LOGIC
	// priority: admin → user deny → user allow → role rules → default open
	// =========================================================================

	private function can_user_access_plugin( $plugin_file, $user_id = 0 ) {
		$user = $user_id ? get_userdata( $user_id ) : wp_get_current_user();
		if ( ! $user || ! $user->ID ) {
			return true;
		}
		if ( user_can( $user, 'manage_options' ) ) {
			return true;
		}

		$user_rules = $this->get_user_plugin_rules();
		if ( isset( $user_rules[ $plugin_file ] ) ) {
			if ( in_array( $user->ID, $user_rules[ $plugin_file ]['denied'] ?? array(), true ) ) {
				return false;
			}
			if ( in_array( $user->ID, $user_rules[ $plugin_file ]['allowed'] ?? array(), true ) ) {
				return true;
			}
		}

		/**
		 * Pro hook: allow group-based rules to override before role-level check.
		 *
		 * @param bool|null $result  null = no override, true/false = final answer
		 * @param string    $plugin_file
		 * @param WP_User   $user
		 */
		$pro_override = apply_filters( 'qaiyo_access_manager_group_access_plugin', null, $plugin_file, $user );
		if ( null !== $pro_override ) {
			return (bool) $pro_override;
		}

		$role_rules = $this->get_plugin_rules();
		return $this->evaluate_role_rule( $role_rules[ $plugin_file ] ?? null, $user );
	}

	private function can_user_access_cpt( $post_type, $user_id = 0 ) {
		$user = $user_id ? get_userdata( $user_id ) : wp_get_current_user();
		// Normalize to a real object. A logged-out visitor (or an invalid ID) is
		// treated as a user with ID 0 and no roles — NOT auto-allowed. This is
		// what makes allow-list rules actually block guests on the front end and
		// in the REST API, instead of silently granting access.
		if ( ! $user ) {
			$user = new WP_User( 0 );
		}

		// Administrators always have full access.
		if ( $user->ID && user_can( $user, 'manage_options' ) ) {
			return true;
		}

		// Per-user overrides (only meaningful for logged-in users).
		if ( $user->ID ) {
			$user_rules = $this->get_user_cpt_rules();
			if ( isset( $user_rules[ $post_type ] ) ) {
				if ( in_array( $user->ID, $user_rules[ $post_type ]['denied'] ?? array(), true ) ) {
					return false;
				}
				if ( in_array( $user->ID, $user_rules[ $post_type ]['allowed'] ?? array(), true ) ) {
					return true;
				}
			}
		}

		/** @see qaiyo_access_manager_group_access_plugin */
		$pro_override = apply_filters( 'qaiyo_access_manager_group_access_cpt', null, $post_type, $user );
		if ( null !== $pro_override ) {
			return (bool) $pro_override;
		}

		// Role rule. A guest has no roles → denied under allow-mode when roles are
		// set, allowed under deny-mode or when no rule is configured.
		$role_rules = $this->get_cpt_rules();
		return $this->evaluate_role_rule( $role_rules[ $post_type ] ?? null, $user );
	}

	/**
	 * Normalize a stored role rule to {mode, roles} shape.
	 *
	 * Accepts both new format (assoc with 'mode' + 'roles') and legacy plain
	 * arrays of role slugs (treated as allow-mode).
	 *
	 * @param mixed $raw Stored value.
	 * @return array { mode: 'allow'|'deny', roles: array<string> }
	 */
	private function normalize_role_rule( $raw ) {
		if ( ! is_array( $raw ) ) {
			return array( 'mode' => 'allow', 'roles' => array() );
		}
		// New format with explicit mode.
		if ( isset( $raw['mode'] ) || isset( $raw['roles'] ) ) {
			return array(
				'mode'  => ( isset( $raw['mode'] ) && 'deny' === $raw['mode'] ) ? 'deny' : 'allow',
				'roles' => isset( $raw['roles'] ) && is_array( $raw['roles'] ) ? array_values( $raw['roles'] ) : array(),
			);
		}
		// Legacy: plain list of role slugs → treat as allow-list.
		return array( 'mode' => 'allow', 'roles' => array_values( $raw ) );
	}

	/**
	 * Apply a role rule to a user.
	 *
	 * Semantics:
	 *  - Empty rule (no roles) → open to everyone.
	 *  - mode=allow → user's role MUST be in the list.
	 *  - mode=deny  → user's role must NOT be in the list.
	 *
	 * @param mixed   $raw_rule Stored rule (any format).
	 * @param WP_User $user
	 * @return bool
	 */
	private function evaluate_role_rule( $raw_rule, $user ) {
		$rule = $this->normalize_role_rule( $raw_rule );
		if ( empty( $rule['roles'] ) ) {
			return true; // Open / no restriction configured.
		}
		$user_roles = ( $user && ! empty( $user->roles ) ) ? (array) $user->roles : array();
		$matches    = (bool) array_intersect( $user_roles, $rule['roles'] );
		return 'deny' === $rule['mode'] ? ! $matches : $matches;
	}

	// =========================================================================
	// NATIVE CAPABILITY INFO
	// =========================================================================

	private function get_roles_with_cap( $cap ) {
		$roles  = wp_roles();
		$result = array();
		foreach ( $roles->roles as $slug => $role_data ) {
			if ( ! empty( $role_data['capabilities'][ $cap ] ) ) {
				$result[ $slug ] = translate_user_role( $role_data['name'] );
			}
		}
		return $result;
	}

	private function get_plugin_native_caps_info() {
		$plugin_caps = array( 'activate_plugins', 'edit_plugins', 'install_plugins', 'update_plugins', 'delete_plugins' );
		$cap_labels  = array(
			'activate_plugins' => __( 'Activate/Deactivate', 'qaiyo-access-manager' ),
			'edit_plugins'     => __( 'Edit', 'qaiyo-access-manager' ),
			'install_plugins'  => __( 'Install', 'qaiyo-access-manager' ),
			'update_plugins'   => __( 'Update', 'qaiyo-access-manager' ),
			'delete_plugins'   => __( 'Delete', 'qaiyo-access-manager' ),
		);
		$info = array();
		foreach ( $plugin_caps as $cap ) {
			$roles_with = $this->get_roles_with_cap( $cap );
			if ( ! empty( $roles_with ) ) {
				$info[ $cap ] = array(
					'label' => $cap_labels[ $cap ],
					'roles' => $roles_with,
				);
			}
		}
		return $info;
	}

	private function get_cpt_native_caps_info( $post_type_obj ) {
		$caps       = (array) $post_type_obj->cap;
		$important  = array( 'edit_posts', 'publish_posts', 'delete_posts', 'edit_others_posts', 'read_private_posts', 'create_posts' );
		$cap_labels = array(
			'edit_posts'         => __( 'Edit', 'qaiyo-access-manager' ),
			'publish_posts'      => __( 'Publish', 'qaiyo-access-manager' ),
			'delete_posts'       => __( 'Delete', 'qaiyo-access-manager' ),
			'edit_others_posts'  => __( 'Edit others', 'qaiyo-access-manager' ),
			'read_private_posts' => __( 'Read private', 'qaiyo-access-manager' ),
			'create_posts'       => __( 'Create', 'qaiyo-access-manager' ),
		);
		$info = array();
		foreach ( $important as $generic_cap ) {
			if ( ! isset( $caps[ $generic_cap ] ) ) {
				continue;
			}
			$actual_cap = $caps[ $generic_cap ];
			$roles_with = $this->get_roles_with_cap( $actual_cap );
			if ( ! empty( $roles_with ) ) {
				$info[ $generic_cap ] = array(
					'label'  => $cap_labels[ $generic_cap ] ?? $generic_cap,
					'wp_cap' => $actual_cap,
					'roles'  => $roles_with,
				);
			}
		}
		return $info;
	}

	// =========================================================================
	// ADMIN MENU & SETTINGS
	// =========================================================================

	public function add_admin_menu() {
		add_menu_page(
			__( 'Qaiyo Access Manager', 'qaiyo-access-manager' ),
			__( 'Access Manager', 'qaiyo-access-manager' ),
			'manage_options',
			'qaiyo-access-manager',
			array( $this, 'render_settings_page' ),
			'dashicons-shield-alt',
			class_exists( 'Qaiyo_Access_Manager_Brand_Menu' ) ? Qaiyo_Access_Manager_Brand_Menu::plugin_position() : 25
		);
	}

	public function register_settings() {
		register_setting( 'wpam_settings_group', 'wpam_plugin_role_rules', array( 'sanitize_callback' => array( $this, 'sanitize_role_rules' ) ) );
		register_setting( 'wpam_settings_group', 'wpam_cpt_role_rules', array( 'sanitize_callback' => array( $this, 'sanitize_cpt_role_rules' ) ) );
		register_setting( 'wpam_settings_group', 'wpam_plugin_user_rules', array( 'sanitize_callback' => array( $this, 'sanitize_plugin_user_rules' ) ) );
		register_setting( 'wpam_settings_group', 'wpam_cpt_user_rules', array( 'sanitize_callback' => array( $this, 'sanitize_cpt_user_rules' ) ) );
	}

	/** Allowlist of installed plugin files (used to validate rule keys). */
	private function valid_plugin_keys() {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		return array_keys( get_plugins() );
	}

	/** Allowlist of registered post type slugs (used to validate rule keys). */
	private function valid_cpt_keys() {
		return array_keys( get_post_types( array(), 'names' ) );
	}

	public function sanitize_role_rules( $input ) {
		if ( ! is_array( $input ) ) {
			return array();
		}
		$sanitized   = array();
		$all_plugins = array_keys( get_plugins() );
		$all_roles   = array_keys( wp_roles()->roles );
		foreach ( $input as $key => $raw_rule ) {
			if ( ! in_array( $key, $all_plugins, true ) ) {
				continue;
			}
			$clean_key  = sanitize_text_field( $key );
			$clean_rule = $this->sanitize_single_role_rule( $raw_rule, $all_roles );
			if ( ! empty( $clean_rule['roles'] ) ) {
				$sanitized[ $clean_key ] = $clean_rule;
			}
		}
		return $sanitized;
	}

	public function sanitize_cpt_role_rules( $input ) {
		if ( ! is_array( $input ) ) {
			return array();
		}
		$sanitized = array();
		$all_roles = array_keys( wp_roles()->roles );
		$valid_pts = $this->valid_cpt_keys();
		foreach ( $input as $pt => $raw_rule ) {
			$clean_pt = sanitize_key( $pt );
			if ( ! in_array( $clean_pt, $valid_pts, true ) ) {
				continue;
			}
			$clean_rule = $this->sanitize_single_role_rule( $raw_rule, $all_roles );
			if ( ! empty( $clean_rule['roles'] ) ) {
				$sanitized[ $clean_pt ] = $clean_rule;
			}
		}
		return $sanitized;
	}

	/**
	 * Sanitize one rule into the canonical {mode, roles} shape.
	 *
	 * Accepts both legacy plain-array format and the new {mode, roles} format.
	 *
	 * @param mixed $raw       Raw rule.
	 * @param array $all_roles Allowlist of registered role slugs.
	 * @return array { mode: string, roles: array<string> }
	 */
	private function sanitize_single_role_rule( $raw, array $all_roles ) {
		$result = array( 'mode' => 'allow', 'roles' => array() );
		if ( ! is_array( $raw ) ) {
			return $result;
		}

		// Detect format.
		if ( isset( $raw['mode'] ) || isset( $raw['roles'] ) ) {
			if ( isset( $raw['mode'] ) && 'deny' === $raw['mode'] ) {
				$result['mode'] = 'deny';
			}
			$roles_in = isset( $raw['roles'] ) && is_array( $raw['roles'] ) ? $raw['roles'] : array();
		} else {
			// Legacy: plain list of role slugs.
			$roles_in = $raw;
		}

		foreach ( $roles_in as $r ) {
			if ( is_string( $r ) && in_array( $r, $all_roles, true ) ) {
				$result['roles'][] = sanitize_key( $r );
			}
		}
		$result['roles'] = array_values( array_unique( $result['roles'] ) );
		return $result;
	}

	/** register_setting callback for plugin user rules (keys allowlisted to installed plugins). */
	public function sanitize_plugin_user_rules( $input ) {
		return $this->sanitize_user_rules_for_keys( $input, $this->valid_plugin_keys(), 'plugin' );
	}

	/** register_setting callback for CPT user rules (keys allowlisted to registered post types). */
	public function sanitize_cpt_user_rules( $input ) {
		return $this->sanitize_user_rules_for_keys( $input, $this->valid_cpt_keys(), 'cpt' );
	}

	/**
	 * Shared user-rule sanitizer. Validates each key against an allowlist and
	 * casts every user ID with absint().
	 *
	 * @param mixed  $input      Raw value.
	 * @param array  $valid_keys Allowlist of acceptable item keys.
	 * @param string $key_type   'plugin' (text field key) or 'cpt' (sanitize_key).
	 */
	private function sanitize_user_rules_for_keys( $input, $valid_keys, $key_type ) {
		if ( ! is_array( $input ) ) {
			return array();
		}
		$sanitized = array();
		foreach ( $input as $key => $data ) {
			$clean_key = 'cpt' === $key_type ? sanitize_key( $key ) : sanitize_text_field( $key );
			if ( ! in_array( $clean_key, $valid_keys, true ) ) {
				continue;
			}
			$sanitized[ $clean_key ] = array(
				'allowed' => array(),
				'denied'  => array(),
			);
			if ( isset( $data['allowed'] ) && is_array( $data['allowed'] ) ) {
				$sanitized[ $clean_key ]['allowed'] = array_map( 'absint', $data['allowed'] );
			}
			if ( isset( $data['denied'] ) && is_array( $data['denied'] ) ) {
				$sanitized[ $clean_key ]['denied'] = array_map( 'absint', $data['denied'] );
			}
		}
		return $sanitized;
	}

	// =========================================================================
	// ADMIN ASSETS
	// =========================================================================

	public function enqueue_admin_assets( $hook ) {
		// Dashboard widget styles (loaded only on the dashboard screen).
		if ( 'index.php' === $hook && current_user_can( 'manage_options' ) ) {
			wp_register_style( 'wpam-dashboard-widget', false, array(), QAIYO_ACCESS_MANAGER_VERSION );
			wp_enqueue_style( 'wpam-dashboard-widget' );
			wp_add_inline_style( 'wpam-dashboard-widget', $this->dashboard_widget_css() );
			return;
		}

		if ( 'toplevel_page_qaiyo-access-manager' !== $hook ) {
			return;
		}

		// Cache-bust assets by file mtime so iterating in-place doesn't require a version bump.
		$css_path = QAIYO_ACCESS_MANAGER_PLUGIN_DIR . 'assets/css/admin.css';
		$js_path  = QAIYO_ACCESS_MANAGER_PLUGIN_DIR . 'assets/js/admin.js';
		$css_ver  = file_exists( $css_path ) ? QAIYO_ACCESS_MANAGER_VERSION . '.' . filemtime( $css_path ) : QAIYO_ACCESS_MANAGER_VERSION;
		$js_ver   = file_exists( $js_path ) ? QAIYO_ACCESS_MANAGER_VERSION . '.' . filemtime( $js_path ) : QAIYO_ACCESS_MANAGER_VERSION;

		wp_enqueue_style( 'wpam-admin', QAIYO_ACCESS_MANAGER_PLUGIN_URL . 'assets/css/admin.css', array(), $css_ver );
		wp_enqueue_script( 'wpam-admin', QAIYO_ACCESS_MANAGER_PLUGIN_URL . 'assets/js/admin.js', array( 'jquery' ), $js_ver, true );

		wp_localize_script( 'wpam-admin', 'wpam_data', array(
			'ajax_url'    => admin_url( 'admin-ajax.php' ),
			'nonce'       => wp_create_nonce( 'wpam_save_access_nonce' ),
			'user_nonce'  => wp_create_nonce( 'wpam_search_users_nonce' ),
			'tools_nonce' => wp_create_nonce( 'wpam_tools_nonce' ),
			'i18n'        => array(
				'saving'          => __( 'Saving...', 'qaiyo-access-manager' ),
				'saved'           => __( 'Settings saved!', 'qaiyo-access-manager' ),
				'error'           => __( 'An error occurred while saving.', 'qaiyo-access-manager' ),
				'search_user'     => __( 'Search user...', 'qaiyo-access-manager' ),
				'allow'           => __( 'Allowed', 'qaiyo-access-manager' ),
				'deny'            => __( 'Denied', 'qaiyo-access-manager' ),
				'remove'          => __( 'Remove', 'qaiyo-access-manager' ),
				'no_results'      => __( 'No results', 'qaiyo-access-manager' ),
				'save_btn'        => __( 'Save settings', 'qaiyo-access-manager' ),
				'exporting'       => __( 'Exporting...', 'qaiyo-access-manager' ),
				'export_done'     => __( 'Export complete!', 'qaiyo-access-manager' ),
				'importing'       => __( 'Importing...', 'qaiyo-access-manager' ),
				'import_done'     => __( 'Settings imported successfully! Reloading...', 'qaiyo-access-manager' ),
				'import_error'    => __( 'Import failed.', 'qaiyo-access-manager' ),
				'invalid_file'    => __( 'Invalid file. Please select a .json file exported from Qaiyo Access Manager.', 'qaiyo-access-manager' ),
				'confirm_import'  => __( 'This will overwrite all current access rules. Continue?', 'qaiyo-access-manager' ),
				'restricted'      => __( 'Restricted', 'qaiyo-access-manager' ),
			),
		) );
	}

	// =========================================================================
	// AJAX HANDLERS
	// =========================================================================

	public function ajax_save_access() {
		check_ajax_referer( 'wpam_save_access_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to perform this action.', 'qaiyo-access-manager' ) ), 403 );
		}

		// Raw JSON payloads: unslash only, then json_decode and sanitize each
		// field via the dedicated sanitize_*_rules() methods. Running
		// sanitize_text_field() on the JSON string first would corrupt it.
		// phpcs:disable WordPress.Security.ValidatedSanitizedInput -- decoded and sanitized field-by-field below.
		$plugin_role_raw = ( isset( $_POST['plugin_role_rules'] ) && is_string( $_POST['plugin_role_rules'] ) ) ? wp_unslash( $_POST['plugin_role_rules'] ) : '{}';
		$cpt_role_raw    = ( isset( $_POST['cpt_role_rules'] ) && is_string( $_POST['cpt_role_rules'] ) ) ? wp_unslash( $_POST['cpt_role_rules'] ) : '{}';
		$plugin_user_raw = ( isset( $_POST['plugin_user_rules'] ) && is_string( $_POST['plugin_user_rules'] ) ) ? wp_unslash( $_POST['plugin_user_rules'] ) : '{}';
		$cpt_user_raw    = ( isset( $_POST['cpt_user_rules'] ) && is_string( $_POST['cpt_user_rules'] ) ) ? wp_unslash( $_POST['cpt_user_rules'] ) : '{}';
		// phpcs:enable

		$plugin_role = json_decode( $plugin_role_raw, true );
		$cpt_role    = json_decode( $cpt_role_raw, true );
		$plugin_user = json_decode( $plugin_user_raw, true );
		$cpt_user    = json_decode( $cpt_user_raw, true );

		/**
		 * Pro hook: snapshot current state before save (for activity log diffing).
		 *
		 * @param array $before Current option values keyed by option name.
		 */
		do_action( 'qaiyo_access_manager_before_save_access', array(
			'wpam_plugin_role_rules' => $this->get_plugin_rules(),
			'wpam_cpt_role_rules'    => $this->get_cpt_rules(),
			'wpam_plugin_user_rules' => $this->get_user_plugin_rules(),
			'wpam_cpt_user_rules'    => $this->get_user_cpt_rules(),
		) );

		update_option( 'wpam_plugin_role_rules', $this->sanitize_role_rules( is_array( $plugin_role ) ? $plugin_role : array() ) );
		update_option( 'wpam_cpt_role_rules', $this->sanitize_cpt_role_rules( is_array( $cpt_role ) ? $cpt_role : array() ) );
		update_option( 'wpam_plugin_user_rules', $this->sanitize_plugin_user_rules( is_array( $plugin_user ) ? $plugin_user : array() ) );
		update_option( 'wpam_cpt_user_rules', $this->sanitize_cpt_user_rules( is_array( $cpt_user ) ? $cpt_user : array() ) );

		$this->clear_option_cache();

		/**
		 * Pro hook: allow Pro modules to save additional data alongside access rules.
		 */
		do_action( 'qaiyo_access_manager_after_save_access' );

		wp_send_json_success( array( 'message' => __( 'Settings saved!', 'qaiyo-access-manager' ) ) );
	}

	public function ajax_search_users() {
		check_ajax_referer( 'wpam_search_users_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array(), 403 );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Nonce already verified above via check_ajax_referer.
		$search = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : '';
		if ( strlen( $search ) < 2 ) {
			wp_send_json_success( array() );
		}

		// Fetch full WP_User objects so roles are available without a second
		// get_userdata() per row.
		$users = get_users( array(
			'search'         => '*' . $search . '*',
			'search_columns' => array( 'user_login', 'user_email', 'display_name' ),
			'number'         => 10,
			'role__not_in'   => array( 'administrator' ),
		) );

		$results = array();
		foreach ( $users as $u ) {
			$results[] = array(
				'id'    => (int) $u->ID,
				'login' => $u->user_login,
				'name'  => $u->display_name,
				'email' => $u->user_email,
				'role'  => implode( ', ', (array) $u->roles ),
			);
		}

		wp_send_json_success( $results );
	}

	// =========================================================================
	// EXPORT / IMPORT
	// =========================================================================

	public function ajax_export() {
		check_ajax_referer( 'wpam_tools_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to perform this action.', 'qaiyo-access-manager' ) ), 403 );
		}

		$data = array(
			'plugin'             => 'qaiyo-access-manager',
			'version'            => QAIYO_ACCESS_MANAGER_VERSION,
			'exported'           => gmdate( 'Y-m-d H:i:s' ),
			'plugin_role_rules'  => get_option( 'wpam_plugin_role_rules', array() ),
			'cpt_role_rules'     => get_option( 'wpam_cpt_role_rules', array() ),
			'plugin_user_rules'  => get_option( 'wpam_plugin_user_rules', array() ),
			'cpt_user_rules'     => get_option( 'wpam_cpt_user_rules', array() ),
		);

		wp_send_json_success( $data );
	}

	public function ajax_import() {
		check_ajax_referer( 'wpam_tools_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to perform this action.', 'qaiyo-access-manager' ) ), 403 );
		}

		// Raw JSON: unslash only, then decode. Values are sanitized per field by
		// the sanitize_*_rules() calls below; sanitizing the JSON text first
		// would corrupt valid payloads.
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- decoded and sanitized field-by-field below.
		$raw_json = ( isset( $_POST['import_data'] ) && is_string( $_POST['import_data'] ) ) ? wp_unslash( $_POST['import_data'] ) : '';
		if ( empty( $raw_json ) ) {
			wp_send_json_error( array( 'message' => __( 'No import data received.', 'qaiyo-access-manager' ) ) );
		}

		$data = json_decode( $raw_json, true );
		if ( ! is_array( $data ) || empty( $data['plugin'] ) || 'qaiyo-access-manager' !== $data['plugin'] ) {
			wp_send_json_error( array( 'message' => __( 'Invalid import file. Please use a file exported from Qaiyo Access Manager.', 'qaiyo-access-manager' ) ) );
		}

		if ( isset( $data['plugin_role_rules'] ) && is_array( $data['plugin_role_rules'] ) ) {
			update_option( 'wpam_plugin_role_rules', $this->sanitize_role_rules( $data['plugin_role_rules'] ) );
		}
		if ( isset( $data['cpt_role_rules'] ) && is_array( $data['cpt_role_rules'] ) ) {
			update_option( 'wpam_cpt_role_rules', $this->sanitize_cpt_role_rules( $data['cpt_role_rules'] ) );
		}
		if ( isset( $data['plugin_user_rules'] ) && is_array( $data['plugin_user_rules'] ) ) {
			update_option( 'wpam_plugin_user_rules', $this->sanitize_plugin_user_rules( $data['plugin_user_rules'] ) );
		}
		if ( isset( $data['cpt_user_rules'] ) && is_array( $data['cpt_user_rules'] ) ) {
			update_option( 'wpam_cpt_user_rules', $this->sanitize_cpt_user_rules( $data['cpt_user_rules'] ) );
		}

		$this->clear_option_cache();

		wp_send_json_success( array( 'message' => __( 'Settings imported successfully!', 'qaiyo-access-manager' ) ) );
	}

	public function ajax_set_delete_data() {
		check_ajax_referer( 'wpam_tools_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array(), 403 );
		}

		$enabled = isset( $_POST['enabled'] ) ? sanitize_text_field( wp_unslash( $_POST['enabled'] ) ) : '0';
		update_option( 'wpam_delete_data_on_uninstall', '1' === $enabled, true );

		wp_send_json_success();
	}

}

Qaiyo_Access_Manager::get_instance();

/**
 * When the free plugin is deactivated, also deactivate the Pro add-on so the
 * pair never runs out of sync (Pro depends on this plugin).
 */
register_deactivation_hook( __FILE__, 'qaiyo_access_manager_deactivate_pro' );
function qaiyo_access_manager_deactivate_pro() {
	$pro = 'qaiyo-access-manager-pro/qaiyo-access-manager-pro.php';
	if ( ! function_exists( 'is_plugin_active' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}
	if ( is_plugin_active( $pro ) ) {
		deactivate_plugins( $pro );
	}
}
