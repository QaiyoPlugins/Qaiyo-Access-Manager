/**
 * Qaiyo Access Manager — Ecosystem page + update-notice interactions.
 */
( function ( $ ) {
	'use strict';

	if ( typeof wpam_ecosystem === 'undefined' ) {
		return;
	}
	var cfg = wpam_ecosystem;

	// Remote icon failed to load → swap to the monogram tile.
	$( '.qae-icon-img' ).on( 'error', function () {
		$( this ).closest( '.qae-icon' ).addClass( 'qae-icon--fallback' );
	} ).each( function () {
		// Handle images already broken before the handler attached.
		if ( this.complete && this.naturalWidth === 0 ) {
			$( this ).closest( '.qae-icon' ).addClass( 'qae-icon--fallback' );
		}
	} );

	// Refresh the remote plugin feed.
	$( document ).on( 'click', '.qae-refresh-btn', function () {
		var $btn = $( this );
		if ( $btn.hasClass( 'is-spinning' ) ) {
			return;
		}
		$btn.addClass( 'is-spinning' ).prop( 'disabled', true );
		$.post( cfg.ajax_url, {
			action: 'qaiyo_ecosystem_refresh',
			nonce:  cfg.nonce
		} ).done( function ( res ) {
			if ( res && res.success ) {
				window.location.reload();
			} else {
				$btn.removeClass( 'is-spinning' ).prop( 'disabled', false );
				window.alert( cfg.i18n.error );
			}
		} ).fail( function () {
			$btn.removeClass( 'is-spinning' ).prop( 'disabled', false );
			window.alert( cfg.i18n.error );
		} );
	} );

	// Persist dismissal of a Qaiyo update notice (per version).
	$( document ).on( 'click', '.qae-update-notice .notice-dismiss', function () {
		var key = $( this ).closest( '.qae-update-notice' ).data( 'dismiss-key' );
		if ( ! key ) {
			return;
		}
		$.post( cfg.ajax_url, {
			action:      'qaiyo_ecosystem_dismiss',
			nonce:       cfg.nonce,
			dismiss_key: key
		} );
	} );

}( jQuery ) );
