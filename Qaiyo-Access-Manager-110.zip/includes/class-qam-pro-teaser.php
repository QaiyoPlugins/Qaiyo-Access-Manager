<?php
/**
 * Pro teaser — locked-card showcase of Pro features inside the free plugin.
 *
 * Catalog lives in the free plugin (titles, descriptions, icons). Pro hooks into
 * `qaiyo_access_manager_pro_active` filter so the lock automatically disappears
 * when the Pro plugin is installed AND its license is active.
 *
 * Design tokens follow the canonical Qaiyo "lakatos" spec (qaiyo-design-system).
 *
 * @package qaiyo-access-manager
 */

defined( 'ABSPATH' ) || exit;

class Qaiyo_Access_Manager_Pro_Teaser {

	const UPGRADE_URL = 'https://qaiyo-plugins.com/qaiyo-access-manager-pro';

	public static function init() {
		// Register the Pro showcase tab in the free nav (read-only, no filter chain needed).
		add_filter( 'qaiyo_access_manager_valid_tabs', array( __CLASS__, 'register_tab' ) );
		add_filter( 'qaiyo_access_manager_hide_toolbar_tabs', array( __CLASS__, 'hide_toolbar' ) );
	}

	/**
	 * Whether the Pro plugin is installed AND active (licensed).
	 *
	 * The Pro plugin's loader sets this filter to true once its license check
	 * passes; we default to false here.
	 */
	public static function is_pro_active() {
		// Hard signal: Pro classes loaded means files are installed; license
		// activation drives the filter below.
		$installed = class_exists( 'Wpamp_Loader' );
		return (bool) apply_filters( 'qaiyo_access_manager_pro_active', $installed && self::pro_license_active() );
	}

	private static function pro_license_active() {
		if ( ! class_exists( 'Qaiyo_Sdk' ) ) {
			return false;
		}
		return Qaiyo_Sdk::is_license_active( 'qaiyo-access-manager-pro' );
	}

	/**
	 * Upgrade URL with simple UTM-style attribution tag.
	 */
	public static function upgrade_url( $location = 'unknown' ) {
		$url = self::UPGRADE_URL . '?ref=free-plugin&loc=' . rawurlencode( $location );
		return (string) apply_filters( 'qaiyo_access_manager_upgrade_url', $url, $location );
	}

	/**
	 * Static catalog of Pro features.
	 *
	 * @return array<string,array{ title:string, summary:string, icon:string, tier:int }>
	 */
	public static function catalog() {
		$items = array(
			'editable-matrix' => array(
				'title'   => __( 'Editable Access Matrix', 'qaiyo-access-manager' ),
				'summary' => __( 'Click any cell to toggle access. Allow/deny mode per row. One save for the whole grid.', 'qaiyo-access-manager' ),
				'icon'    => 'dashicons-screenoptions',
				'tier'    => 1,
			),
			'presets' => array(
				'title'   => __( 'Rule Presets', 'qaiyo-access-manager' ),
				'summary' => __( 'Save a set of rules under a name ("Editor basics", "Shop manager") and apply with one click.', 'qaiyo-access-manager' ),
				'icon'    => 'dashicons-portfolio',
				'tier'    => 1,
			),
			'user-groups' => array(
				'title'   => __( 'User Groups', 'qaiyo-access-manager' ),
				'summary' => __( 'Define groups beyond WP roles. Members get access to checked items even if their role wouldn\'t.', 'qaiyo-access-manager' ),
				'icon'    => 'dashicons-groups',
				'tier'    => 1,
			),
			'bulk-actions' => array(
				'title'   => __( 'Bulk Actions', 'qaiyo-access-manager' ),
				'summary' => __( 'Multi-select plugins or CPTs, apply allow/deny + roles to all at once, or clear rules in bulk.', 'qaiyo-access-manager' ),
				'icon'    => 'dashicons-forms',
				'tier'    => 1,
			),
			'temp-access' => array(
				'title'   => __( 'Temporary Access', 'qaiyo-access-manager' ),
				'summary' => __( 'Grant time-limited allow/deny with an expiry date. Auto-cleanup nightly + 24h reminder email.', 'qaiyo-access-manager' ),
				'icon'    => 'dashicons-clock',
				'tier'    => 2,
			),
			'activity-log' => array(
				'title'   => __( 'Activity Log', 'qaiyo-access-manager' ),
				'summary' => __( 'Every rule change logged with before/after diff. Searchable, paginated, CSV-exportable.', 'qaiyo-access-manager' ),
				'icon'    => 'dashicons-list-view',
				'tier'    => 2,
			),
			'admin-pages' => array(
				'title'   => __( 'Admin Page Hiding', 'qaiyo-access-manager' ),
				'summary' => __( 'Hide any WP admin menu item (Settings, Tools, custom plugin pages) by role. Subpage-level granularity.', 'qaiyo-access-manager' ),
				'icon'    => 'dashicons-hidden',
				'tier'    => 2,
			),
			'notifications' => array(
				'title'   => __( 'Email Notifications', 'qaiyo-access-manager' ),
				'summary' => __( 'On rule change, on temp expiry, plus a weekly activity digest. Multi-recipient.', 'qaiyo-access-manager' ),
				'icon'    => 'dashicons-email-alt',
				'tier'    => 2,
			),
		);
		return (array) apply_filters( 'qaiyo_access_manager_pro_catalog', $items );
	}

	// =========================================================================
	// TAB REGISTRATION
	// =========================================================================

	public static function register_tab( $tabs ) {
		$tabs[] = 'pro';
		return $tabs;
	}

	public static function hide_toolbar( $tabs ) {
		$tabs[] = 'pro';
		return $tabs;
	}

	// =========================================================================
	// TAB NAV LINK (rendered from the main plugin's tab nav)
	// =========================================================================

	/**
	 * Output a "Pro" tab link in the main nav. Skipped when Pro is fully active.
	 */
	public static function render_nav_link( $active_tab ) {
		if ( self::is_pro_active() ) {
			return;
		}
		$url = add_query_arg( 'tab', 'pro', admin_url( 'admin.php?page=qaiyo-access-manager' ) );
		?>
		<a href="<?php echo esc_url( $url ); ?>" class="nav-tab wpam-pro-nav-tab <?php echo 'pro' === $active_tab ? 'nav-tab-active' : ''; ?>">
			<span class="dashicons dashicons-unlock"></span>
			<?php esc_html_e( 'Unlock Pro', 'qaiyo-access-manager' ); ?>
		</a>
		<?php
	}

	// =========================================================================
	// FULL SHOWCASE — the Pro tab content
	// =========================================================================

	public static function render_showcase() {
		$items   = self::catalog();
		$tier_1  = array_filter( $items, static function ( $i ) {
			return 1 === ( $i['tier'] ?? 1 );
		} );
		$tier_2  = array_filter( $items, static function ( $i ) {
			return 2 === ( $i['tier'] ?? 1 );
		} );
		?>
		<div class="wpam-pro-showcase">
			<div class="wpam-pro-hero">
				<div class="wpam-pro-hero-text">
					<span class="wpam-pro-badge-pill">PRO</span>
					<h2><?php esc_html_e( 'Qaiyo Access Manager Pro', 'qaiyo-access-manager' ); ?></h2>
					<p><?php esc_html_e( '8 modules that turn this plugin from "power-user" into "enterprise". One license, two pricing options, no surprises.', 'qaiyo-access-manager' ); ?></p>
					<div class="wpam-pro-cta-row">
						<a href="<?php echo esc_url( self::upgrade_url( 'showcase-hero' ) ); ?>" target="_blank" rel="noopener noreferrer" class="button button-primary wpam-pro-cta-btn">
							<?php esc_html_e( 'See pricing & upgrade', 'qaiyo-access-manager' ); ?>
							<span aria-hidden="true">&rarr;</span>
						</a>
						<span class="wpam-pro-pricing-inline"><?php echo esc_html__( '$80 / year (8 sites) · $224 lifetime (24 sites)', 'qaiyo-access-manager' ); ?></span>
					</div>
				</div>
			</div>

			<h3 class="wpam-pro-tier-title">
				<span class="wpam-pro-tier-num">1</span>
				<?php esc_html_e( 'Administration & efficiency', 'qaiyo-access-manager' ); ?>
			</h3>
			<div class="wpam-pro-grid">
				<?php foreach ( $tier_1 as $key => $item ) {
					self::render_locked_card( $key, $item );
				} ?>
			</div>

			<h3 class="wpam-pro-tier-title" style="margin-top:24px;">
				<span class="wpam-pro-tier-num">2</span>
				<?php esc_html_e( 'Security & control', 'qaiyo-access-manager' ); ?>
			</h3>
			<div class="wpam-pro-grid">
				<?php foreach ( $tier_2 as $key => $item ) {
					self::render_locked_card( $key, $item );
				} ?>
			</div>

			<div class="wpam-pro-bottom-cta">
				<div>
					<strong><?php esc_html_e( 'Ready to unlock everything?', 'qaiyo-access-manager' ); ?></strong>
					<p><?php esc_html_e( 'License covers all current and future Pro modules. Auto-updates via the Qaiyo Licensing Server.', 'qaiyo-access-manager' ); ?></p>
				</div>
				<a href="<?php echo esc_url( self::upgrade_url( 'showcase-bottom' ) ); ?>" target="_blank" rel="noopener noreferrer" class="button button-primary wpam-pro-cta-btn">
					<?php esc_html_e( 'Get Pro', 'qaiyo-access-manager' ); ?>
					<span aria-hidden="true">&rarr;</span>
				</a>
			</div>
		</div>
		<?php
	}

	/**
	 * One locked Pro card.
	 *
	 * @param string $key  Catalog key.
	 * @param array  $item Catalog entry.
	 */
	public static function render_locked_card( $key, $item ) {
		$url = self::upgrade_url( 'card-' . $key );
		?>
		<a href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener noreferrer"
		   class="wpam-pro-card wpam-pro-locked" data-pro-feature="<?php echo esc_attr( $key ); ?>">
			<span class="wpam-pro-card-badge">PRO</span>
			<div class="wpam-pro-card-preview">
				<span class="dashicons <?php echo esc_attr( $item['icon'] ); ?>"></span>
				<span class="wpam-pro-lock-overlay" aria-hidden="true">
					<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" fill="#fff">
						<path d="M6 10V8a6 6 0 1 1 12 0v2h1a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-9a1 1 0 0 1 1-1h1zm2 0h8V8a4 4 0 1 0-8 0v2z"/>
					</svg>
				</span>
			</div>
			<div class="wpam-pro-card-body">
				<h4><?php echo esc_html( $item['title'] ); ?></h4>
				<p><?php echo esc_html( $item['summary'] ); ?></p>
				<span class="wpam-pro-unlock-link">
					<?php esc_html_e( 'Unlock in Pro', 'qaiyo-access-manager' ); ?>
					<span aria-hidden="true">&rarr;</span>
				</span>
			</div>
		</a>
		<?php
	}

	// =========================================================================
	// INLINE TEASERS (in-context callouts)
	// =========================================================================

	/**
	 * Banner above the read-only Matrix tab inviting upgrade to the editable matrix.
	 */
	public static function render_matrix_banner() {
		if ( self::is_pro_active() ) {
			return;
		}
		?>
		<div class="wpam-pro-inline-banner">
			<div class="wpam-pro-inline-icon">
				<span class="dashicons dashicons-edit"></span>
			</div>
			<div class="wpam-pro-inline-text">
				<strong><?php esc_html_e( 'Make this matrix editable', 'qaiyo-access-manager' ); ?></strong>
				<span><?php esc_html_e( 'With Pro you can click any cell to toggle access, with a per-row Allow/Deny switch. Save the whole grid in one go.', 'qaiyo-access-manager' ); ?></span>
			</div>
			<a href="<?php echo esc_url( self::upgrade_url( 'matrix-banner' ) ); ?>" target="_blank" rel="noopener noreferrer" class="wpam-pro-inline-cta">
				<?php esc_html_e( 'Unlock in Pro', 'qaiyo-access-manager' ); ?> <span aria-hidden="true">&rarr;</span>
			</a>
		</div>
		<?php
	}

	/**
	 * Render the trio of Tools-tab teasers (Activity Log, Temp Access, Notifications)
	 * below the existing tools so the user discovers them in context.
	 */
	public static function render_tools_teaser() {
		if ( self::is_pro_active() ) {
			return;
		}
		$items   = self::catalog();
		$picked  = array( 'activity-log', 'temp-access', 'admin-pages' );
		?>
		<div class="wpam-pro-tools-teaser">
			<div class="wpam-pro-tools-header">
				<span class="wpam-pro-badge-pill">PRO</span>
				<h3><?php esc_html_e( 'More with Pro', 'qaiyo-access-manager' ); ?></h3>
			</div>
			<div class="wpam-pro-grid wpam-pro-grid-3">
				<?php foreach ( $picked as $key ) {
					if ( isset( $items[ $key ] ) ) {
						self::render_locked_card( $key, $items[ $key ] );
					}
				} ?>
			</div>
		</div>
		<?php
	}
}
