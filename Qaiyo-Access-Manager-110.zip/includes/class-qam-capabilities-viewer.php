<?php
/**
 * Capabilities Viewer — read-only inspector of every role's capabilities.
 *
 * Renders a searchable capability × role matrix so admins can see at a glance
 * which roles hold which capability. Does NOT edit capabilities (that is what
 * dedicated role editors are for); this is a diagnostic view.
 *
 * @package qaiyo-access-manager
 */

defined( 'ABSPATH' ) || exit;

class Qaiyo_Access_Manager_Capabilities_Viewer {

	/**
	 * Core WordPress capabilities (used to flag "default" vs plugin-added caps).
	 */
	private static function core_caps() {
		return array(
			'switch_themes', 'edit_themes', 'activate_plugins', 'edit_plugins', 'edit_users',
			'edit_files', 'manage_options', 'moderate_comments', 'manage_categories',
			'manage_links', 'upload_files', 'import', 'unfiltered_html', 'edit_posts',
			'edit_others_posts', 'edit_published_posts', 'publish_posts', 'edit_pages',
			'read', 'level_0', 'level_1', 'level_2', 'level_3', 'level_4', 'level_5',
			'level_6', 'level_7', 'level_8', 'level_9', 'level_10', 'edit_others_pages',
			'edit_published_pages', 'publish_pages', 'delete_pages', 'delete_others_pages',
			'delete_published_pages', 'delete_posts', 'delete_others_posts',
			'delete_published_posts', 'delete_private_posts', 'edit_private_posts',
			'read_private_posts', 'delete_private_pages', 'edit_private_pages',
			'read_private_pages', 'delete_users', 'create_users', 'unfiltered_upload',
			'edit_dashboard', 'update_plugins', 'delete_plugins', 'install_plugins',
			'update_themes', 'install_themes', 'update_core', 'list_users', 'remove_users',
			'promote_users', 'edit_theme_options', 'delete_themes', 'export',
		);
	}

	public static function render() {
		$roles      = wp_roles()->roles;
		$core       = self::core_caps();

		// Build role display names and the full capability universe.
		$role_names = array();
		$all_caps   = array();
		foreach ( $roles as $slug => $role ) {
			$role_names[ $slug ] = translate_user_role( $role['name'] );
			foreach ( (array) $role['capabilities'] as $cap => $granted ) {
				if ( $granted ) {
					$all_caps[ $cap ] = true;
				}
			}
		}
		$all_caps = array_keys( $all_caps );
		sort( $all_caps );
		?>
		<div class="wpam-caps-wrap">
			<p class="wpam-hint">
				<?php esc_html_e( 'Read-only overview of every capability and which roles hold it. Use the search box to filter capabilities. Core WordPress capabilities are marked; the rest are added by plugins or themes.', 'qaiyo-access-manager' ); ?>
			</p>

			<div class="wpam-caps-toolbar">
				<input type="text" id="wpam-caps-search"
					placeholder="<?php esc_attr_e( 'Search by capability name (e.g. edit_posts, manage_options)…', 'qaiyo-access-manager' ); ?>" />
				<label class="wpam-caps-filter">
					<input type="checkbox" id="wpam-caps-custom-only" />
					<?php esc_html_e( 'Plugin/theme capabilities only', 'qaiyo-access-manager' ); ?>
				</label>
				<span class="wpam-caps-count"><?php echo (int) count( $all_caps ); ?> <?php esc_html_e( 'capabilities', 'qaiyo-access-manager' ); ?></span>
			</div>

			<div class="wpam-matrix-scroll">
				<table class="wpam-matrix-table wpam-caps-table">
					<thead>
						<tr>
							<th class="wpam-matrix-item-col"><?php esc_html_e( 'Capability', 'qaiyo-access-manager' ); ?></th>
							<?php foreach ( $role_names as $rname ) : ?>
								<th class="wpam-matrix-role-col"><?php echo esc_html( $rname ); ?></th>
							<?php endforeach; ?>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $all_caps as $cap ) :
							$is_core = in_array( $cap, $core, true );
						?>
							<tr class="wpam-caps-row" data-cap="<?php echo esc_attr( $cap ); ?>" data-core="<?php echo $is_core ? '1' : '0'; ?>">
								<td class="wpam-matrix-item-name">
									<code><?php echo esc_html( $cap ); ?></code>
									<?php if ( $is_core ) : ?>
										<span class="wpam-badge wpam-badge-inactive"><?php esc_html_e( 'core', 'qaiyo-access-manager' ); ?></span>
									<?php else : ?>
										<span class="wpam-badge wpam-badge-cpt"><?php esc_html_e( 'plugin', 'qaiyo-access-manager' ); ?></span>
									<?php endif; ?>
								</td>
								<?php foreach ( array_keys( $role_names ) as $rslug ) :
									$has = ! empty( $roles[ $rslug ]['capabilities'][ $cap ] );
								?>
									<td class="wpam-matrix-cell">
										<?php if ( $has ) : ?>
											<span class="wpam-matrix-allowed" title="<?php esc_attr_e( 'Has capability', 'qaiyo-access-manager' ); ?>">&#10003;</span>
										<?php else : ?>
											<span class="wpam-matrix-open" title="<?php esc_attr_e( 'No', 'qaiyo-access-manager' ); ?>">&middot;</span>
										<?php endif; ?>
									</td>
								<?php endforeach; ?>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>

			<p class="wpam-caps-empty" id="wpam-caps-empty" style="display:none;"
				data-msg-default="<?php esc_attr_e( 'No capabilities match your search.', 'qaiyo-access-manager' ); ?>"
				data-msg-nocustom="<?php esc_attr_e( 'No plugin or theme capabilities found — every capability on this site is a WordPress core capability.', 'qaiyo-access-manager' ); ?>">
				<?php esc_html_e( 'No capabilities match your search.', 'qaiyo-access-manager' ); ?>
			</p>
		</div>
		<?php
	}
}
