<?php
/**
 * Dashboard widget visibility by role.
 *
 * Removes selected dashboard widgets for users whose role is configured to
 * hide them. Administrators always see everything; visiting the Dashboard also
 * refreshes the snapshot of available widgets used by the Options UI.
 *
 * Storage: wpam_options['dashboard_hidden'] = [ widget_id => [ role_slug, ... ] ]
 * Snapshot: wpam_dashboard_widget_snapshot = [ widget_id => title ]
 *
 * @package qaiyo-access-manager
 */

defined( 'ABSPATH' ) || exit;

class Qaiyo_Access_Manager_Dashboard_Widgets {

	const SNAPSHOT_KEY = 'wpam_dashboard_widget_snapshot';

	public static function init() {
		// Late priority so every plugin/theme widget is registered first.
		add_action( 'wp_dashboard_setup', array( __CLASS__, 'maybe_filter' ), 9999 );
	}

	public static function maybe_filter() {
		// Admins: refresh the snapshot and keep all widgets.
		if ( current_user_can( 'manage_options' ) ) {
			self::capture_snapshot();
			return;
		}

		$hidden = Qaiyo_Access_Manager_Options::get( 'dashboard_hidden', array() );
		if ( empty( $hidden ) || ! is_array( $hidden ) ) {
			return;
		}

		$user = wp_get_current_user();
		if ( ! $user || ! $user->ID ) {
			return;
		}
		$roles = (array) $user->roles;

		foreach ( $hidden as $widget_id => $widget_roles ) {
			if ( is_array( $widget_roles ) && array_intersect( $roles, $widget_roles ) ) {
				self::remove_widget( $widget_id );
			}
		}
	}

	/**
	 * Remove a dashboard widget by id from every context/priority.
	 */
	private static function remove_widget( $widget_id ) {
		global $wp_meta_boxes;
		if ( empty( $wp_meta_boxes['dashboard'] ) ) {
			return;
		}
		foreach ( $wp_meta_boxes['dashboard'] as $context => $priorities ) {
			foreach ( $priorities as $priority => $widgets ) {
				if ( isset( $widgets[ $widget_id ] ) ) {
					unset( $wp_meta_boxes['dashboard'][ $context ][ $priority ][ $widget_id ] );
				}
			}
		}
	}

	/**
	 * Snapshot the currently registered dashboard widgets (id => title).
	 */
	public static function capture_snapshot() {
		global $wp_meta_boxes;
		if ( empty( $wp_meta_boxes['dashboard'] ) ) {
			return;
		}
		$snap = array();
		foreach ( $wp_meta_boxes['dashboard'] as $context => $priorities ) {
			foreach ( $priorities as $priority => $widgets ) {
				foreach ( $widgets as $id => $widget ) {
					if ( empty( $id ) || empty( $widget['title'] ) ) {
						continue;
					}
					$snap[ $id ] = wp_strip_all_tags( $widget['title'] );
				}
			}
		}
		if ( $snap ) {
			update_option( self::SNAPSHOT_KEY, $snap, false );
		}
	}

	/**
	 * Get the snapshot (id => title) for the Options UI.
	 */
	public static function get_snapshot() {
		$snap = get_option( self::SNAPSHOT_KEY, array() );
		return is_array( $snap ) ? $snap : array();
	}
}
