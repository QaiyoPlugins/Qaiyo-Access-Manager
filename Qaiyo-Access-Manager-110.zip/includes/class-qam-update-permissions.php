<?php
/**
 * Update permissions — grants update_plugins / update_themes to selected roles
 * at runtime, without modifying the stored role capabilities in the database.
 *
 * Uses the user_has_cap filter so the grant is dynamic and fully reversible:
 * removing the role from the Options tab instantly removes the capability.
 *
 * @package qaiyo-access-manager
 */

defined( 'ABSPATH' ) || exit;

class Qaiyo_Access_Manager_Update_Permissions {

	public static function init() {
		add_filter( 'user_has_cap', array( __CLASS__, 'grant_caps' ), 10, 4 );
	}

	/**
	 * @param array   $allcaps All capabilities the user has.
	 * @param array   $caps    Required primitive caps for the requested meta cap.
	 * @param array   $args    [ requested_cap, user_id, ... ].
	 * @param WP_User $user    The user object.
	 */
	public static function grant_caps( $allcaps, $caps, $args, $user ) {
		if ( ! ( $user instanceof WP_User ) || empty( $user->roles ) ) {
			return $allcaps;
		}

		$plugins_roles = Qaiyo_Access_Manager_Options::get( 'update_plugins_roles', array() );
		$themes_roles  = Qaiyo_Access_Manager_Options::get( 'update_themes_roles', array() );

		$user_roles = (array) $user->roles;

		if ( is_array( $plugins_roles ) && array_intersect( $user_roles, $plugins_roles ) ) {
			$allcaps['update_plugins'] = true;
		}
		if ( is_array( $themes_roles ) && array_intersect( $user_roles, $themes_roles ) ) {
			$allcaps['update_themes'] = true;
		}

		return $allcaps;
	}
}
