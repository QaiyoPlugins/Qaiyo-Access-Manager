<?php
/**
 * Admin bar control.
 *
 *  - Hide the whole front-end toolbar for selected roles.
 *  - Hide specific admin bar items (New, Comments, WP logo, Updates, …) for
 *    selected roles, on both the front end and wp-admin.
 *
 * Storage:
 *   wpam_options['admin_bar_hidden_roles']  = [ role_slug, ... ]   (whole bar, frontend)
 *   wpam_options['admin_bar_hidden_nodes']  = [ node_id => [ role_slug, ... ] ]
 *
 * @package qaiyo-access-manager
 */

defined( 'ABSPATH' ) || exit;

class Qaiyo_Access_Manager_Admin_Bar {

	public static function init() {
		add_filter( 'show_admin_bar', array( __CLASS__, 'maybe_hide' ) );
		add_action( 'admin_bar_menu', array( __CLASS__, 'maybe_hide_nodes' ), 9999 );
	}

	/**
	 * Curated list of common admin-bar nodes that can be hidden.
	 *
	 * @return array<string,string> node_id => label
	 */
	public static function known_nodes() {
		return array(
			'wp-logo'      => __( 'WordPress logo', 'qaiyo-access-manager' ),
			'site-name'    => __( 'Site name', 'qaiyo-access-manager' ),
			'updates'      => __( 'Updates', 'qaiyo-access-manager' ),
			'comments'     => __( 'Comments', 'qaiyo-access-manager' ),
			'new-content'  => __( '+ New', 'qaiyo-access-manager' ),
			'search'       => __( 'Search', 'qaiyo-access-manager' ),
			'customize'    => __( 'Customize', 'qaiyo-access-manager' ),
			'my-account'   => __( 'My account / Howdy', 'qaiyo-access-manager' ),
		);
	}

	public static function maybe_hide( $show ) {
		// Whole-bar hiding affects the front end only; never touch wp-admin.
		if ( is_admin() || ! is_user_logged_in() ) {
			return $show;
		}

		$hidden = Qaiyo_Access_Manager_Options::get( 'admin_bar_hidden_roles', array() );
		if ( empty( $hidden ) || ! is_array( $hidden ) ) {
			return $show;
		}

		$user = wp_get_current_user();
		if ( $user && array_intersect( (array) $user->roles, $hidden ) ) {
			return false;
		}

		return $show;
	}

	/**
	 * Remove specific admin-bar nodes for the current user's roles.
	 *
	 * @param WP_Admin_Bar $wp_admin_bar
	 */
	public static function maybe_hide_nodes( $wp_admin_bar ) {
		if ( ! is_user_logged_in() ) {
			return;
		}
		$rules = Qaiyo_Access_Manager_Options::get( 'admin_bar_hidden_nodes', array() );
		if ( empty( $rules ) || ! is_array( $rules ) ) {
			return;
		}

		$user  = wp_get_current_user();
		$roles = (array) $user->roles;

		foreach ( $rules as $node_id => $node_roles ) {
			if ( is_array( $node_roles ) && array_intersect( $roles, $node_roles ) ) {
				$wp_admin_bar->remove_node( $node_id );
			}
		}
	}
}
