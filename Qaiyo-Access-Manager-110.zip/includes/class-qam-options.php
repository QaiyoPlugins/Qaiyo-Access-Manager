<?php
/**
 * Options tab — central store + UI for the free behavior settings:
 *  - Restricted access message customization
 *  - CPT frontend redirect target
 *  - Login redirect by role
 *  - Admin bar visibility by role
 *  - Plugin / theme update permissions by role
 *
 * All values live in a single option: wpam_options.
 *
 * @package qaiyo-access-manager
 */

defined( 'ABSPATH' ) || exit;

class Qaiyo_Access_Manager_Options {

	const OPTION_KEY = 'wpam_options';

	/** @var array|null Per-request cache of merged options. */
	private static $cache = null;

	public static function init() {
		add_action( 'wp_ajax_wpam_save_options', array( __CLASS__, 'ajax_save' ) );
	}

	/**
	 * Default option values.
	 */
	public static function defaults() {
		return array(
			'restricted_notice_type'    => 'info',   // info | warning | error | none
			'restricted_notice_message' => '',       // empty => default text
			'cpt_redirect_type'         => 'home',   // home | 404 | login | custom
			'cpt_redirect_url'          => '',
			'login_redirects'           => array(),  // role_slug => url
			'admin_bar_hidden_roles'    => array(),  // [ role_slug ]
			'admin_bar_hidden_nodes'    => array(),  // node_id => [ role_slug, ... ]
			'dashboard_hidden'          => array(),  // widget_id => [ role_slug, ... ]
			'update_plugins_roles'      => array(),  // [ role_slug ]
			'update_themes_roles'       => array(),  // [ role_slug ]
		);
	}

	/**
	 * Get the whole options array (merged with defaults).
	 */
	public static function all() {
		if ( null !== self::$cache ) {
			return self::$cache;
		}
		$stored = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}
		self::$cache = wp_parse_args( $stored, self::defaults() );
		return self::$cache;
	}

	/**
	 * Get a single option value.
	 */
	public static function get( $key, $default = null ) {
		$all = self::all();
		return array_key_exists( $key, $all ) ? $all[ $key ] : $default;
	}

	/**
	 * Editable (non-admin) roles helper.
	 */
	private static function editable_roles() {
		$roles    = wp_roles()->roles;
		$editable = array();
		foreach ( $roles as $slug => $role ) {
			if ( 'administrator' === $slug ) {
				continue;
			}
			$editable[ $slug ] = translate_user_role( $role['name'] );
		}
		return $editable;
	}

	// =========================================================================
	// RENDER
	// =========================================================================

	public static function render() {
		$o     = self::all();
		$roles = self::editable_roles();
		?>
		<div class="wpam-options-wrap">

			<!-- Restricted access message -->
			<div class="wpam-options-section">
				<h3><span class="dashicons dashicons-warning"></span> <?php esc_html_e( 'Restricted access message', 'qaiyo-access-manager' ); ?></h3>
				<p class="wpam-hint"><?php esc_html_e( 'Shown to restricted users on the Plugins page when some plugins are hidden from them.', 'qaiyo-access-manager' ); ?></p>

				<div class="wpam-opt-row">
					<label for="wpam-notice-type"><?php esc_html_e( 'Notice style', 'qaiyo-access-manager' ); ?></label>
					<select id="wpam-notice-type">
						<option value="info" <?php selected( $o['restricted_notice_type'], 'info' ); ?>><?php esc_html_e( 'Info (blue)', 'qaiyo-access-manager' ); ?></option>
						<option value="warning" <?php selected( $o['restricted_notice_type'], 'warning' ); ?>><?php esc_html_e( 'Warning (yellow)', 'qaiyo-access-manager' ); ?></option>
						<option value="error" <?php selected( $o['restricted_notice_type'], 'error' ); ?>><?php esc_html_e( 'Error (red)', 'qaiyo-access-manager' ); ?></option>
						<option value="none" <?php selected( $o['restricted_notice_type'], 'none' ); ?>><?php esc_html_e( 'Hide the notice', 'qaiyo-access-manager' ); ?></option>
					</select>
				</div>

				<div class="wpam-opt-row">
					<label for="wpam-notice-message"><?php esc_html_e( 'Custom message', 'qaiyo-access-manager' ); ?></label>
					<textarea id="wpam-notice-message" rows="2" class="large-text" placeholder="<?php esc_attr_e( 'Leave empty to use the default text.', 'qaiyo-access-manager' ); ?>"><?php echo esc_textarea( $o['restricted_notice_message'] ); ?></textarea>
					<p class="wpam-hint"><?php esc_html_e( 'Placeholders: {user_name}, {site_name}, {admin_email}', 'qaiyo-access-manager' ); ?></p>
				</div>
			</div>

			<!-- CPT frontend redirect -->
			<div class="wpam-options-section">
				<h3><span class="dashicons dashicons-external"></span> <?php esc_html_e( 'Restricted content redirect (frontend)', 'qaiyo-access-manager' ); ?></h3>
				<p class="wpam-hint"><?php esc_html_e( 'Where to send a logged-in user who opens a single page of a content type they cannot access.', 'qaiyo-access-manager' ); ?></p>
				<div class="wpam-opt-row">
					<label for="wpam-cpt-redirect-type"><?php esc_html_e( 'Redirect to', 'qaiyo-access-manager' ); ?></label>
					<select id="wpam-cpt-redirect-type">
						<option value="home" <?php selected( $o['cpt_redirect_type'], 'home' ); ?>><?php esc_html_e( 'Home page', 'qaiyo-access-manager' ); ?></option>
						<option value="404" <?php selected( $o['cpt_redirect_type'], '404' ); ?>><?php esc_html_e( 'Show 404 (not found)', 'qaiyo-access-manager' ); ?></option>
						<option value="login" <?php selected( $o['cpt_redirect_type'], 'login' ); ?>><?php esc_html_e( 'Login page', 'qaiyo-access-manager' ); ?></option>
						<option value="custom" <?php selected( $o['cpt_redirect_type'], 'custom' ); ?>><?php esc_html_e( 'Custom URL', 'qaiyo-access-manager' ); ?></option>
					</select>
				</div>
				<div class="wpam-opt-row wpam-cpt-custom-url" <?php echo 'custom' !== $o['cpt_redirect_type'] ? 'style="display:none;"' : ''; ?>>
					<label for="wpam-cpt-redirect-url"><?php esc_html_e( 'Custom URL', 'qaiyo-access-manager' ); ?></label>
					<input type="url" id="wpam-cpt-redirect-url" class="regular-text" value="<?php echo esc_attr( $o['cpt_redirect_url'] ); ?>" placeholder="https://example.com/no-access/" />
				</div>
			</div>

			<!-- Login redirect by role -->
			<div class="wpam-options-section">
				<h3><span class="dashicons dashicons-migrate"></span> <?php esc_html_e( 'Login redirect by role', 'qaiyo-access-manager' ); ?></h3>
				<p class="wpam-hint"><?php esc_html_e( 'Send users to a specific URL right after they log in, based on their role. Leave empty to use the WordPress default.', 'qaiyo-access-manager' ); ?></p>
				<table class="wpam-opt-table">
					<tbody>
						<?php foreach ( $roles as $slug => $name ) : ?>
							<tr>
								<td class="wpam-opt-role-name"><?php echo esc_html( $name ); ?></td>
								<td>
									<input type="url" class="wpam-login-redirect regular-text" data-role="<?php echo esc_attr( $slug ); ?>"
										value="<?php echo esc_attr( $o['login_redirects'][ $slug ] ?? '' ); ?>"
										placeholder="<?php echo esc_attr( admin_url() ); ?>" />
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>

			<!-- Admin bar -->
			<div class="wpam-options-section">
				<h3><span class="dashicons dashicons-admin-generic"></span> <?php esc_html_e( 'Hide admin bar on the frontend', 'qaiyo-access-manager' ); ?></h3>
				<p class="wpam-hint"><?php esc_html_e( 'Hide the top WordPress toolbar on the front of the site for the selected roles.', 'qaiyo-access-manager' ); ?></p>
				<div class="wpam-roles-grid">
					<?php foreach ( $roles as $slug => $name ) : ?>
						<label class="wpam-role-checkbox">
							<input type="checkbox" class="wpam-adminbar-cb" value="<?php echo esc_attr( $slug ); ?>"
								<?php checked( in_array( $slug, (array) $o['admin_bar_hidden_roles'], true ) ); ?> />
							<span class="wpam-role-name"><?php echo esc_html( $name ); ?></span>
						</label>
					<?php endforeach; ?>
				</div>
			</div>

			<!-- Admin bar items -->
			<div class="wpam-options-section">
				<h3><span class="dashicons dashicons-menu"></span> <?php esc_html_e( 'Hide specific admin bar items', 'qaiyo-access-manager' ); ?></h3>
				<p class="wpam-hint"><?php esc_html_e( 'Remove individual items from the top toolbar (front end and wp-admin) for the selected roles.', 'qaiyo-access-manager' ); ?></p>
				<?php
				self::render_item_role_matrix(
					'wpam-adminbar-node',
					Qaiyo_Access_Manager_Admin_Bar::known_nodes(),
					(array) $o['admin_bar_hidden_nodes'],
					$roles
				);
				?>
			</div>

			<!-- Dashboard widgets -->
			<div class="wpam-options-section">
				<h3><span class="dashicons dashicons-dashboard"></span> <?php esc_html_e( 'Hide dashboard widgets', 'qaiyo-access-manager' ); ?></h3>
				<p class="wpam-hint"><?php esc_html_e( 'Remove dashboard widgets for the selected roles. The list is built from widgets seen on your Dashboard.', 'qaiyo-access-manager' ); ?></p>
				<?php
				$dash = Qaiyo_Access_Manager_Dashboard_Widgets::get_snapshot();
				if ( empty( $dash ) ) :
					?>
					<p class="wpam-hint" style="font-style:italic;">
						<?php esc_html_e( 'Visit your WordPress Dashboard once to populate this list.', 'qaiyo-access-manager' ); ?>
					</p>
					<?php
				else :
					self::render_item_role_matrix(
						'wpam-dashwidget',
						$dash,
						(array) $o['dashboard_hidden'],
						$roles
					);
				endif;
				?>
			</div>

			<!-- Update permissions -->
			<div class="wpam-options-section">
				<h3><span class="dashicons dashicons-update"></span> <?php esc_html_e( 'Update permissions', 'qaiyo-access-manager' ); ?></h3>
				<p class="wpam-hint"><?php esc_html_e( 'Allow non-admin roles to update plugins and/or themes, without giving them full administrator access.', 'qaiyo-access-manager' ); ?></p>

				<div class="wpam-inline-warning" style="display:flex;gap:10px;align-items:flex-start;padding:12px 14px;margin:4px 0 16px;border-left:4px solid #d98300;background:#fff8ec;border-radius:6px;">
					<span class="dashicons dashicons-warning" style="color:#d98300;flex:0 0 auto;"></span>
					<span style="font-size:13px;line-height:1.5;color:#5a4a2a;">
						<strong><?php esc_html_e( 'Security warning:', 'qaiyo-access-manager' ); ?></strong>
						<?php esc_html_e( 'Updating plugins or themes runs and replaces executable code on your site. A role granted this capability can deploy code that affects the entire installation — treat it as nearly equivalent to administrator access and grant it only to roles you fully trust.', 'qaiyo-access-manager' ); ?>
					</span>
				</div>

				<h4><?php esc_html_e( 'Can update plugins', 'qaiyo-access-manager' ); ?></h4>
				<div class="wpam-roles-grid">
					<?php foreach ( $roles as $slug => $name ) : ?>
						<label class="wpam-role-checkbox">
							<input type="checkbox" class="wpam-updateplugins-cb" value="<?php echo esc_attr( $slug ); ?>"
								<?php checked( in_array( $slug, (array) $o['update_plugins_roles'], true ) ); ?> />
							<span class="wpam-role-name"><?php echo esc_html( $name ); ?></span>
						</label>
					<?php endforeach; ?>
				</div>

				<h4 style="margin-top:14px;"><?php esc_html_e( 'Can update themes', 'qaiyo-access-manager' ); ?></h4>
				<div class="wpam-roles-grid">
					<?php foreach ( $roles as $slug => $name ) : ?>
						<label class="wpam-role-checkbox">
							<input type="checkbox" class="wpam-updatethemes-cb" value="<?php echo esc_attr( $slug ); ?>"
								<?php checked( in_array( $slug, (array) $o['update_themes_roles'], true ) ); ?> />
							<span class="wpam-role-name"><?php echo esc_html( $name ); ?></span>
						</label>
					<?php endforeach; ?>
				</div>
			</div>

			<!-- Shortcode reference -->
			<div class="wpam-options-section wpam-shortcode-ref">
				<h3><span class="dashicons dashicons-shortcode"></span> <?php esc_html_e( 'Content protection shortcode', 'qaiyo-access-manager' ); ?></h3>
				<p class="wpam-hint"><?php esc_html_e( 'Wrap any content to show or hide it based on the visitor. Works in posts, pages and most page builders.', 'qaiyo-access-manager' ); ?></p>
				<pre class="wpam-code-block">[qaiyo_protect role="editor,shop_manager"]<?php esc_html_e( 'Only these roles can see this.', 'qaiyo-access-manager' ); ?>[/qaiyo_protect]

[qaiyo_protect deny="subscriber"]<?php esc_html_e( 'Subscribers cannot see this.', 'qaiyo-access-manager' ); ?>[/qaiyo_protect]

[qaiyo_protect logged_in="yes"]<?php esc_html_e( 'Only logged-in users.', 'qaiyo-access-manager' ); ?>[/qaiyo_protect]

[qaiyo_protect cap="manage_woocommerce" message="<?php esc_attr_e( 'No access.', 'qaiyo-access-manager' ); ?>"]<?php esc_html_e( 'Requires the capability above.', 'qaiyo-access-manager' ); ?>[/qaiyo_protect]</pre>
				<p class="wpam-hint"><?php esc_html_e( 'Attributes: role (allow list), deny (deny list), logged_in (yes/no), cap (capability), message (text shown instead when hidden).', 'qaiyo-access-manager' ); ?></p>
			</div>

			<div class="wpam-options-savebar">
				<button type="button" class="button button-primary" id="wpam-options-save-btn"><?php esc_html_e( 'Save options', 'qaiyo-access-manager' ); ?></button>
				<span class="wpam-tool-status" id="wpam-options-status"></span>
			</div>
		</div>
		<?php
	}

	/**
	 * Render an "item × roles" matrix: one row per item, a checkbox per role.
	 *
	 * @param string $css_class Shared CSS/JS class on each checkbox.
	 * @param array  $items     [ item_id => label ].
	 * @param array  $stored    [ item_id => [ role_slug, ... ] ].
	 * @param array  $roles     [ role_slug => display name ].
	 */
	private static function render_item_role_matrix( $css_class, $items, $stored, $roles ) {
		?>
		<div class="wpam-irt-scroll">
		<table class="wpam-item-role-table" data-group="<?php echo esc_attr( $css_class ); ?>">
			<thead>
				<tr>
					<th class="wpam-irt-item wpam-irt-item--head"></th>
					<?php foreach ( $roles as $rname ) : ?>
						<th class="wpam-irt-role">
							<span class="wpam-irt-role-label"><?php echo esc_html( $rname ); ?></span>
						</th>
					<?php endforeach; ?>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $items as $item_id => $label ) :
					$item_roles = isset( $stored[ $item_id ] ) && is_array( $stored[ $item_id ] ) ? $stored[ $item_id ] : array();
				?>
					<tr data-item-id="<?php echo esc_attr( $item_id ); ?>">
						<td class="wpam-irt-item"><?php echo esc_html( $label ); ?></td>
						<?php foreach ( array_keys( $roles ) as $rslug ) : ?>
							<td class="wpam-irt-cell">
								<input type="checkbox" class="<?php echo esc_attr( $css_class ); ?>"
									data-role="<?php echo esc_attr( $rslug ); ?>"
									<?php checked( in_array( $rslug, $item_roles, true ) ); ?> />
							</td>
						<?php endforeach; ?>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		</div>
		<?php
	}

	// =========================================================================
	// AJAX SAVE
	// =========================================================================

	public static function ajax_save() {
		check_ajax_referer( 'wpam_tools_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to perform this action.', 'qaiyo-access-manager' ) ), 403 );
		}

		// Raw JSON: unslash only, then decode. Each field is sanitized
		// individually below (whitelists, sanitize_textarea_field, esc_url_raw…).
		// Sanitizing the JSON string first would, for example, flatten the
		// multi-line restricted-notice message.
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- decoded and sanitized field-by-field below.
		$raw = isset( $_POST['options'] ) ? wp_unslash( $_POST['options'] ) : '{}';
		$in  = is_string( $raw ) ? json_decode( $raw, true ) : null;
		if ( ! is_array( $in ) ) {
			$in = array();
		}

		$all_roles  = array_keys( wp_roles()->roles );
		$clean      = self::defaults();

		// Notice type.
		if ( isset( $in['restricted_notice_type'] ) && in_array( $in['restricted_notice_type'], array( 'info', 'warning', 'error', 'none' ), true ) ) {
			$clean['restricted_notice_type'] = $in['restricted_notice_type'];
		}
		// Notice message.
		if ( isset( $in['restricted_notice_message'] ) ) {
			$clean['restricted_notice_message'] = sanitize_textarea_field( $in['restricted_notice_message'] );
		}
		// CPT redirect.
		if ( isset( $in['cpt_redirect_type'] ) && in_array( $in['cpt_redirect_type'], array( 'home', '404', 'login', 'custom' ), true ) ) {
			$clean['cpt_redirect_type'] = $in['cpt_redirect_type'];
		}
		if ( isset( $in['cpt_redirect_url'] ) ) {
			$clean['cpt_redirect_url'] = esc_url_raw( $in['cpt_redirect_url'] );
		}
		// Login redirects.
		if ( isset( $in['login_redirects'] ) && is_array( $in['login_redirects'] ) ) {
			foreach ( $in['login_redirects'] as $role => $url ) {
				if ( in_array( $role, $all_roles, true ) ) {
					$url = esc_url_raw( $url );
					if ( $url ) {
						$clean['login_redirects'][ sanitize_key( $role ) ] = $url;
					}
				}
			}
		}
		// Admin bar hidden roles.
		$clean['admin_bar_hidden_roles'] = self::clean_role_list( $in['admin_bar_hidden_roles'] ?? array(), $all_roles );
		// Admin bar hidden nodes (item_id => [roles]).
		$clean['admin_bar_hidden_nodes'] = self::clean_item_role_map( $in['admin_bar_hidden_nodes'] ?? array(), $all_roles );
		// Dashboard widgets hidden (widget_id => [roles]).
		$clean['dashboard_hidden'] = self::clean_item_role_map( $in['dashboard_hidden'] ?? array(), $all_roles );
		// Update perms.
		$clean['update_plugins_roles'] = self::clean_role_list( $in['update_plugins_roles'] ?? array(), $all_roles );
		$clean['update_themes_roles']  = self::clean_role_list( $in['update_themes_roles'] ?? array(), $all_roles );

		update_option( self::OPTION_KEY, $clean );
		self::$cache = null;

		wp_send_json_success( array( 'message' => __( 'Options saved.', 'qaiyo-access-manager' ) ) );
	}

	private static function clean_role_list( $list, $all_roles ) {
		if ( ! is_array( $list ) ) {
			return array();
		}
		$out = array();
		foreach ( $list as $r ) {
			if ( is_string( $r ) && in_array( $r, $all_roles, true ) && 'administrator' !== $r ) {
				$out[] = sanitize_key( $r );
			}
		}
		return array_values( array_unique( $out ) );
	}

	/**
	 * Sanitize an item_id => [role_slugs] map. Drops empty entries and admin role.
	 */
	private static function clean_item_role_map( $map, $all_roles ) {
		if ( ! is_array( $map ) ) {
			return array();
		}
		$out = array();
		foreach ( $map as $item_id => $role_list ) {
			$clean_id = sanitize_text_field( (string) $item_id );
			if ( '' === $clean_id ) {
				continue;
			}
			$roles = self::clean_role_list( is_array( $role_list ) ? $role_list : array(), $all_roles );
			if ( ! empty( $roles ) ) {
				$out[ $clean_id ] = $roles;
			}
		}
		return $out;
	}
}
