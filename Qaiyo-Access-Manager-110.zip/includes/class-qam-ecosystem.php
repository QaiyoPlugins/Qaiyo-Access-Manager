<?php
/**
 * Qaiyo Ecosystem — "Explore Qaiyo Plugins" page + update notifications.
 *
 * Fetches plugin data from a remote JSON feed (24 h transient cache).
 * Falls back to a hardcoded list when the feed is unreachable.
 *
 * @package qaiyo-access-manager
 */

defined( 'ABSPATH' ) || exit;

class Qaiyo_Access_Manager_Ecosystem {

	const TRANSIENT_KEY  = 'qaiyo_ecosystem_feed';
	const DISMISS_OPTION = 'qaiyo_ecosystem_dismissed';
	const FEED_URL       = 'https://qaiyo-plugins.com/plugins.json';
	const CACHE_TTL      = DAY_IN_SECONDS;
	const PAGE_SLUG      = 'qaiyo-ecosystem';

	/** Hook suffix of our submenu page, captured at registration. */
	private static $page_hook = '';

	/** Fallback list used when the remote feed is unreachable. */
	private static $fallback = array(
		array(
			'slug'        => 'qaiyo-access-manager',
			'name'        => 'Qaiyo Access Manager',
			'version'     => '1.1.0',
			'description' => array(
				'en' => 'Fine-grained role and user-level access control for plugins, custom post types, the admin bar and the dashboard.',
				'hu' => 'Részletes szerepkör- és felhasználó szintű hozzáférés-vezérlés pluginekhez, egyedi post típusokhoz, admin sávhoz és vezérlőpulthoz.',
				'de' => 'Detaillierte Rollen- und Benutzerzugriffssteuerung für Plugins, benutzerdefinierte Beitragstypen, Adminleiste und Dashboard.',
				'fr' => 'Contrôle d\'accès détaillé par rôle et utilisateur pour les extensions, les types de contenus personnalisés, la barre d\'admin et le tableau de bord.',
				'es' => 'Control de acceso detallado por rol y usuario para plugins, tipos de contenido personalizados, barra de administración y panel.',
			),
			'icon'        => 'https://qaiyo-plugins.com/assets/icons/qaiyo-access-manager.svg',
			'free_url'    => 'https://qaiyo-plugins.com/qaiyo-access-manager',
			'pro_url'     => 'https://qaiyo-plugins.com/qaiyo-access-manager-pro',
			'has_pro'     => true,
		),
		array(
			'slug'        => 'qaiyo-featured-image-bulk-replacer',
			'name'        => 'Qaiyo Featured Image Bulk Replacer',
			'version'     => '1.2.0',
			'description' => array(
				'en' => 'Bulk-replace featured images on published posts in one click — filter by date, category and scope, with preview and one-click restore.',
				'hu' => 'Tömeges kiemelt kép csere egy kattintással — szűrés dátum, kategória és hatókör szerint, előnézettel és visszaállítással.',
				'de' => 'Beitragsbilder in einem Klick massenhaft ersetzen — nach Datum, Kategorie und Umfang filtern, mit Vorschau und Wiederherstellung.',
				'fr' => 'Remplacez les images à la une en masse d\'un seul clic — filtrez par date, catégorie et portée, avec aperçu et restauration.',
				'es' => 'Reemplaza imágenes destacadas en masa con un clic — filtra por fecha, categoría y alcance, con vista previa y restauración.',
			),
			'icon'        => 'https://qaiyo-plugins.com/assets/icons/qaiyo-featured-image-bulk-replacer.svg',
			'free_url'    => 'https://qaiyo-plugins.com/qaiyo-featured-image-bulk-replacer',
			'pro_url'     => 'https://qaiyo-plugins.com/qaiyo-featured-image-bulk-replacer-pro',
			'has_pro'     => true,
		),
		array(
			'slug'        => 'qaiyo-social-video-embed',
			'name'        => 'Qaiyo Social Video Embed',
			'version'     => '1.0.0',
			'description' => array(
				'en' => 'Modern TikTok and YouTube (Shorts + regular) video galleries with mixed feeds, lazy load, click-to-play and high-res thumbnails.',
				'hu' => 'Modern TikTok és YouTube (Shorts + normál) videó galériák vegyes feedekkel, lazy load-dal és nagy felbontású borítóképekkel.',
				'de' => 'Moderne TikTok- und YouTube-Videogalerien mit gemischten Feeds, Lazy Load und hochauflösenden Vorschaubildern.',
				'fr' => 'Galeries vidéo TikTok et YouTube modernes avec flux mixtes, chargement différé et miniatures haute résolution.',
				'es' => 'Galerías de vídeo modernas de TikTok y YouTube con feeds mixtos, carga diferida y miniaturas de alta resolución.',
			),
			'icon'        => 'https://qaiyo-plugins.com/assets/icons/qaiyo-social-video-embed.svg',
			'free_url'    => 'https://qaiyo-plugins.com/qaiyo-social-video-embed',
			'pro_url'     => 'https://qaiyo-plugins.com/qaiyo-social-video-embed-pro',
			'has_pro'     => true,
		),
		array(
			'slug'        => 'qaiyo-wp-admin-booster',
			'name'        => 'Qaiyo WP Admin Booster',
			'version'     => '1.0.0',
			'description' => array(
				'en' => 'Fixes the daily annoyances in the WordPress admin: page collections, visual filters, 1-click plugin upload, always-open block inserter, SVG/WebP/AVIF support and more.',
				'hu' => 'Kijavítja a WordPress admin napi bosszúságait: oldal-kollekciók, vizuális szűrők, 1 kattintásos plugin feltöltés, állandóan nyitott blokk illesztő, SVG/WebP/AVIF és még sok más.',
				'de' => 'Behebt die täglichen Ärgernisse im WordPress-Admin: Seitensammlungen, visuelle Filter, 1-Klick-Plugin-Upload, immer geöffneter Block-Inserter, SVG/WebP/AVIF und mehr.',
				'fr' => 'Corrige les problèmes quotidiens de l\'admin WordPress : collections de pages, filtres visuels, envoi de plugin en 1 clic, inserteur de blocs toujours ouvert, SVG/WebP/AVIF.',
				'es' => 'Soluciona los problemas diarios del admin de WordPress: colecciones de páginas, filtros visuales, carga de plugins con 1 clic, insertador de bloques siempre abierto, SVG/WebP/AVIF.',
			),
			'icon'        => 'https://qaiyo-plugins.com/assets/icons/qaiyo-wp-admin-booster.svg',
			'free_url'    => 'https://qaiyo-plugins.com/qaiyo-wp-admin-booster',
			'pro_url'     => 'https://qaiyo-plugins.com/qaiyo-wp-admin-booster-pro',
			'has_pro'     => true,
		),
		array(
			'slug'        => 'qaiyo-testimonials',
			'name'        => 'Qaiyo Testimonials',
			'version'     => '1.1.0',
			'description' => array(
				'en' => '6 testimonial layouts (rows, columns, carousel, bento grid, avatar switcher, photo hero card) with a visual Display Builder and Schema.org rich snippets.',
				'hu' => '6 vélemény elrendezés (sorok, oszlopok, körhinta, bento rács, avatár váltó, fotós hero kártya) vizuális Display Builderrel és Schema.org rich snippettel.',
				'de' => '6 Testimonial-Layouts mit visuellem Display Builder und Schema.org Rich Snippets.',
				'fr' => '6 mises en page de témoignages avec un constructeur d\'affichage visuel et des extraits enrichis Schema.org.',
				'es' => '6 diseños de testimonios con un constructor de pantalla visual y fragmentos enriquecidos Schema.org.',
			),
			'icon'        => 'https://qaiyo-plugins.com/assets/icons/qaiyo-testimonials.svg',
			'free_url'    => 'https://qaiyo-plugins.com/qaiyo-testimonials',
			'pro_url'     => 'https://qaiyo-plugins.com/qaiyo-testimonials-pro',
			'has_pro'     => true,
		),
		array(
			'slug'        => 'qaiyo-clean-gallery',
			'name'        => 'Qaiyo Clean Gallery',
			'version'     => '0.6.1',
			'description' => array(
				'en' => 'Lightweight gallery plugin with Grid, Masonry, Lightbox, filtering and lazy loading — zero dependencies, custom block and shortcode.',
				'hu' => 'Könnyűsúlyú galéria plugin Grid, Masonry, Lightbox, szűrő és lazy loading funkcióval — nulla függőséggel, saját blokk és shortcode.',
				'de' => 'Leichtgewichtiges Galerie-Plugin mit Grid, Masonry, Lightbox, Filter und Lazy Loading — ohne Abhängigkeiten.',
				'fr' => 'Plugin de galerie léger avec grille, maçonnerie, lightbox, filtrage et chargement différé — sans dépendances.',
				'es' => 'Plugin de galería ligero con cuadrícula, mampostería, lightbox, filtrado y carga diferida — sin dependencias.',
			),
			'icon'        => 'https://qaiyo-plugins.com/assets/icons/qaiyo-clean-gallery.svg',
			'free_url'    => 'https://qaiyo-plugins.com/qaiyo-clean-gallery',
			'pro_url'     => '',
			'has_pro'     => false,
		),
		array(
			'slug'        => 'qaiyo-text-marquee-slider',
			'name'        => 'Qaiyo Text Marquee Slider',
			'version'     => '1.0',
			'description' => array(
				'en' => 'Customizable animated marquee slider with rows, icons, separators and fading edges — fully block-editor compatible.',
				'hu' => 'Testreszabható animált marquee slider sorokkal, ikonokkal, elválasztókkal és halványuló szélekkel — blokk szerkesztővel kompatibilis.',
				'de' => 'Anpassbarer animierter Marquee-Slider mit Zeilen, Symbolen, Trennzeichen und verblassenden Rändern.',
				'fr' => 'Curseur marquee animé et personnalisable avec des rangées, des icônes, des séparateurs et des bords estompés.',
				'es' => 'Deslizador marquee animado personalizable con filas, iconos, separadores y bordes desvanecidos.',
			),
			'icon'        => 'https://qaiyo-plugins.com/assets/icons/qaiyo-text-marquee-slider.svg',
			'free_url'    => 'https://qaiyo-plugins.com/qaiyo-text-marquee-slider',
			'pro_url'     => '',
			'has_pro'     => false,
		),
	);

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_submenu' ), 30 );
		add_action( 'admin_notices', array( __CLASS__, 'maybe_update_notices' ) );
		add_action( 'wp_ajax_qaiyo_ecosystem_refresh', array( __CLASS__, 'ajax_refresh' ) );
		add_action( 'wp_ajax_qaiyo_ecosystem_dismiss', array( __CLASS__, 'ajax_dismiss_update' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'maybe_enqueue' ) );
	}

	public static function register_submenu() {
		self::$page_hook = add_submenu_page(
			'qaiyo-access-manager',
			esc_html__( 'Explore Qaiyo Plugins', 'qaiyo-access-manager' ),
			esc_html__( 'Explore Qaiyo', 'qaiyo-access-manager' ),
			'manage_options',
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Enqueue assets:
	 * - ecosystem.js + localized data on any Qaiyo admin screen (so the update
	 *   notice's dismiss persists wherever the notice can appear).
	 * - ecosystem.css only on the "Explore Qaiyo" page.
	 */
	public static function maybe_enqueue( $hook ) {
		$is_qaiyo_screen = ( false !== strpos( $hook, 'qaiyo' ) );
		$is_eco_page     = ( self::$page_hook && $hook === self::$page_hook );

		if ( ! $is_qaiyo_screen && ! $is_eco_page ) {
			return;
		}

		$js_path = QAIYO_ACCESS_MANAGER_PLUGIN_DIR . 'assets/js/ecosystem.js';
		$js_ver  = file_exists( $js_path ) ? QAIYO_ACCESS_MANAGER_VERSION . '.' . filemtime( $js_path ) : QAIYO_ACCESS_MANAGER_VERSION;

		wp_enqueue_script(
			'qaiyo-ecosystem',
			QAIYO_ACCESS_MANAGER_PLUGIN_URL . 'assets/js/ecosystem.js',
			array( 'jquery' ),
			$js_ver,
			true
		);
		wp_localize_script(
			'qaiyo-ecosystem',
			'wpam_ecosystem',
			array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'qaiyo_ecosystem_nonce' ),
				'i18n'     => array(
					'refreshing' => __( 'Refreshing…', 'qaiyo-access-manager' ),
					'refreshed'  => __( 'Plugin list refreshed!', 'qaiyo-access-manager' ),
					'error'      => __( 'An error occurred.', 'qaiyo-access-manager' ),
				),
			)
		);

		if ( $is_eco_page ) {
			$css_path = QAIYO_ACCESS_MANAGER_PLUGIN_DIR . 'assets/css/ecosystem.css';
			$css_ver  = file_exists( $css_path ) ? QAIYO_ACCESS_MANAGER_VERSION . '.' . filemtime( $css_path ) : QAIYO_ACCESS_MANAGER_VERSION;
			wp_enqueue_style(
				'qaiyo-ecosystem',
				QAIYO_ACCESS_MANAGER_PLUGIN_URL . 'assets/css/ecosystem.css',
				array(),
				$css_ver
			);
			wp_enqueue_style( 'dashicons' );
		}
	}

	/**
	 * Build a 1–2 letter monogram from a plugin name, skipping the "Qaiyo" prefix.
	 */
	private static function monogram( $name ) {
		$name  = trim( preg_replace( '/^Qaiyo\s+/i', '', (string) $name ) );
		$words = preg_split( '/\s+/', $name );
		$first = isset( $words[0][0] ) ? $words[0][0] : 'Q';
		$mono  = strtoupper( $first );
		if ( isset( $words[1][0] ) ) {
			$mono .= strtoupper( $words[1][0] );
		}
		return $mono;
	}

	// -------------------------------------------------------------------------
	// Feed
	// -------------------------------------------------------------------------

	public static function get_feed() {
		$cached = get_transient( self::TRANSIENT_KEY );
		if ( false !== $cached && is_array( $cached ) ) {
			return $cached;
		}
		return self::fetch_feed();
	}

	private static function fetch_feed() {
		$response = wp_remote_get(
			self::FEED_URL,
			array(
				'timeout'   => 5,
				'sslverify' => true,
				'headers'   => array( 'Accept' => 'application/json' ),
			)
		);

		if ( ! is_wp_error( $response ) && 200 === wp_remote_retrieve_response_code( $response ) ) {
			$body = json_decode( wp_remote_retrieve_body( $response ), true );
			if ( ! empty( $body['plugins'] ) && is_array( $body['plugins'] ) ) {
				set_transient( self::TRANSIENT_KEY, $body['plugins'], self::CACHE_TTL );
				return $body['plugins'];
			}
		}

		// Cache the fallback briefly to avoid hammering the server on every page load.
		set_transient( self::TRANSIENT_KEY, self::$fallback, HOUR_IN_SECONDS );
		return self::$fallback;
	}

	// -------------------------------------------------------------------------
	// Helpers
	// -------------------------------------------------------------------------

	private static function locale_string( $field ) {
		if ( ! is_array( $field ) ) {
			return (string) $field;
		}
		$locale = determine_locale();
		$lang   = substr( $locale, 0, 2 );
		if ( isset( $field[ $lang ] ) ) {
			return $field[ $lang ];
		}
		if ( isset( $field['en'] ) ) {
			return $field['en'];
		}
		return (string) reset( $field );
	}

	private static function plugin_status( $slug ) {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		foreach ( get_plugins() as $basename => $data ) {
			if ( 0 === strpos( $basename, $slug . '/' ) ) {
				return is_plugin_active( $basename ) ? 'active' : 'installed';
			}
		}
		return 'none';
	}

	private static function installed_version( $slug ) {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		foreach ( get_plugins() as $basename => $data ) {
			if ( 0 === strpos( $basename, $slug . '/' ) ) {
				return isset( $data['Version'] ) ? $data['Version'] : '';
			}
		}
		return '';
	}

	// -------------------------------------------------------------------------
	// Update notices
	// -------------------------------------------------------------------------

	public static function maybe_update_notices() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$screen = get_current_screen();
		if ( ! $screen || false === strpos( $screen->id, 'qaiyo' ) ) {
			return;
		}

		// Megosztott guard: több aktív Qaiyo plugin esetén csak EGY rendereli az
		// értesítőket (elkerüli a duplikátumot).
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Intentional cross-plugin shared global in the qaiyo_ namespace.
		if ( ! empty( $GLOBALS['qaiyo_ecosystem_notices_rendered'] ) ) {
			return;
		}
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- See above.
		$GLOBALS['qaiyo_ecosystem_notices_rendered'] = true;

		$plugins   = self::get_feed();
		$dismissed = get_option( self::DISMISS_OPTION, array() );
		if ( ! is_array( $dismissed ) ) {
			$dismissed = array();
		}

		foreach ( $plugins as $plugin ) {
			$slug = isset( $plugin['slug'] ) ? $plugin['slug'] : '';
			if ( ! $slug ) {
				continue;
			}

			$installed = self::installed_version( $slug );
			if ( ! $installed ) {
				continue; // Not installed → skip.
			}

			$feed_ver = isset( $plugin['version'] ) ? $plugin['version'] : '';
			if ( ! $feed_ver || ! version_compare( $feed_ver, $installed, '>' ) ) {
				continue;
			}

			$key = sanitize_key( $slug . '_' . $feed_ver );
			if ( in_array( $key, $dismissed, true ) ) {
				continue;
			}

			$name     = self::locale_string( isset( $plugin['name'] ) ? $plugin['name'] : $slug );
			$free_url = isset( $plugin['free_url'] ) ? $plugin['free_url'] : '';
			$pro_url  = isset( $plugin['pro_url'] ) ? $plugin['pro_url'] : '';
			$link     = $pro_url ? $pro_url : $free_url;
			?>
			<div class="notice notice-info qae-update-notice is-dismissible"
				 data-dismiss-key="<?php echo esc_attr( $key ); ?>">
				<p>
					<span class="qae-notice-brand">
						<svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg" style="vertical-align:-2px;margin-right:4px"><circle cx="7" cy="7" r="7" fill="#6c5ce7"/><path d="M4 7.5L6.2 9.5L10 5" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
						<strong><?php echo esc_html( $name ); ?></strong>
					</span>
					<?php
					printf(
						/* translators: 1: new version number, 2: installed version number */
						esc_html__( 'version %1$s is available (you have %2$s).', 'qaiyo-access-manager' ),
						'<strong>' . esc_html( $feed_ver ) . '</strong>',
						esc_html( $installed )
					);
					?>
					<?php if ( $link ) : ?>
						&nbsp;<a href="<?php echo esc_url( $link ); ?>" target="_blank" rel="noopener noreferrer">
							<?php esc_html_e( 'View release →', 'qaiyo-access-manager' ); ?>
						</a>
					<?php endif; ?>
				</p>
			</div>
			<?php
		}
	}

	// -------------------------------------------------------------------------
	// AJAX
	// -------------------------------------------------------------------------

	public static function ajax_refresh() {
		check_ajax_referer( 'qaiyo_ecosystem_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Forbidden' ) );
		}
		delete_transient( self::TRANSIENT_KEY );
		$plugins = self::fetch_feed();
		wp_send_json_success( array( 'count' => count( $plugins ) ) );
	}

	public static function ajax_dismiss_update() {
		check_ajax_referer( 'qaiyo_ecosystem_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Forbidden' ) );
		}
		$key       = sanitize_key( wp_unslash( isset( $_POST['dismiss_key'] ) ? $_POST['dismiss_key'] : '' ) );
		$dismissed = get_option( self::DISMISS_OPTION, array() );
		if ( ! is_array( $dismissed ) ) {
			$dismissed = array();
		}
		if ( $key && ! in_array( $key, $dismissed, true ) ) {
			$dismissed[] = $key;
			update_option( self::DISMISS_OPTION, $dismissed, false );
		}
		wp_send_json_success();
	}

	// -------------------------------------------------------------------------
	// Page render
	// -------------------------------------------------------------------------

	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$plugins   = self::get_feed();
		$self_slug = 'qaiyo-access-manager';
		$nonce     = wp_create_nonce( 'qaiyo_ecosystem_nonce' );

		// Split: this plugin first, rest sorted alphabetically by name.
		$current  = null;
		$rest     = array();
		foreach ( $plugins as $p ) {
			if ( isset( $p['slug'] ) && $p['slug'] === $self_slug ) {
				$current = $p;
			} else {
				$rest[] = $p;
			}
		}
		usort( $rest, function( $a, $b ) {
			return strcmp(
				self::locale_string( isset( $a['name'] ) ? $a['name'] : '' ),
				self::locale_string( isset( $b['name'] ) ? $b['name'] : '' )
			);
		} );
		if ( $current ) {
			array_unshift( $rest, $current );
		}
		?>
		<div class="wrap qae-wrap">
			<div class="qae-header">
				<h1>
					<span class="qae-brand">Qaiyo</span>
					<?php esc_html_e( 'Plugins', 'qaiyo-access-manager' ); ?>
				</h1>
				<p class="qae-subtitle">
					<?php esc_html_e( 'The complete Qaiyo plugin family — all built to the same quality standard.', 'qaiyo-access-manager' ); ?>
				</p>
			</div>

			<div class="qae-toolbar">
				<button type="button" class="button qae-refresh-btn" data-nonce="<?php echo esc_attr( $nonce ); ?>">
					<span class="dashicons dashicons-update"></span>
					<?php esc_html_e( 'Refresh list', 'qaiyo-access-manager' ); ?>
				</button>
				<span class="qae-source-hint">
					<?php
					esc_html_e( 'Data from', 'qaiyo-access-manager' );
					echo ' <a href="https://qaiyo-plugins.com" target="_blank" rel="noopener noreferrer">qaiyo-plugins.com</a>';
					// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped — static URL only.
					?>
				</span>
			</div>

			<div class="qae-grid">
			<?php foreach ( $rest as $plugin ) :
				$slug        = isset( $plugin['slug'] ) ? $plugin['slug'] : '';
				$name        = self::locale_string( isset( $plugin['name'] ) ? $plugin['name'] : $slug );
				$desc        = self::locale_string( isset( $plugin['description'] ) ? $plugin['description'] : '' );
				$icon        = isset( $plugin['icon'] ) ? $plugin['icon'] : '';
				$feed_ver    = isset( $plugin['version'] ) ? $plugin['version'] : '';
				$free_url    = isset( $plugin['free_url'] ) ? $plugin['free_url'] : '';
				$pro_url     = isset( $plugin['pro_url'] ) ? $plugin['pro_url'] : '';
				$has_pro     = ! empty( $plugin['has_pro'] );
				$is_self     = ( $slug === $self_slug );
				$status      = self::plugin_status( $slug );
				$inst_ver    = self::installed_version( $slug );
				$has_update  = ( $inst_ver && $feed_ver && version_compare( $feed_ver, $inst_ver, '>' ) );
				$mono        = self::monogram( $name );
				?>
				<div class="qae-card<?php echo $is_self ? ' qae-card--self' : ''; ?>">

					<div class="qae-card-head">
						<div class="qae-icon<?php echo $icon ? '' : ' qae-icon--fallback'; ?>">
							<?php if ( $icon ) : ?>
								<img class="qae-icon-img" src="<?php echo esc_url( $icon ); ?>" alt="" width="46" height="46" loading="lazy">
							<?php endif; ?>
							<span class="qae-icon-mono"><?php echo esc_html( $mono ); ?></span>
						</div>
						<div class="qae-badges">
							<?php if ( 'active' === $status ) : ?>
								<span class="qae-badge qae-badge--active">
									<span class="dashicons dashicons-yes-alt"></span>
									<?php esc_html_e( 'Active', 'qaiyo-access-manager' ); ?>
								</span>
							<?php elseif ( 'installed' === $status ) : ?>
								<span class="qae-badge qae-badge--installed">
									<?php esc_html_e( 'Installed', 'qaiyo-access-manager' ); ?>
								</span>
							<?php endif; ?>
							<?php if ( $has_update ) : ?>
								<span class="qae-badge qae-badge--update">
									<span class="dashicons dashicons-update-alt"></span>
									<?php echo esc_html( $feed_ver ); ?>
								</span>
							<?php endif; ?>
							<?php if ( $has_pro ) : ?>
								<span class="qae-badge qae-badge--pro">PRO</span>
							<?php endif; ?>
						</div>
					</div>

					<div class="qae-card-body">
						<h3 class="qae-name"><?php echo esc_html( $name ); ?></h3>
						<?php if ( $feed_ver ) : ?>
							<span class="qae-version">v<?php echo esc_html( $feed_ver ); ?></span>
						<?php endif; ?>
						<p class="qae-desc"><?php echo esc_html( $desc ); ?></p>
					</div>

					<div class="qae-card-footer">
						<?php if ( $free_url ) : ?>
							<a href="<?php echo esc_url( $free_url ); ?>"
							   target="_blank" rel="noopener noreferrer"
							   class="button qae-btn-free">
								<?php esc_html_e( 'Free Download', 'qaiyo-access-manager' ); ?>
							</a>
						<?php endif; ?>
						<?php if ( $has_pro && $pro_url ) : ?>
							<a href="<?php echo esc_url( $pro_url ); ?>"
							   target="_blank" rel="noopener noreferrer"
							   class="button qae-btn-pro">
								<?php esc_html_e( 'Go Pro →', 'qaiyo-access-manager' ); ?>
							</a>
						<?php endif; ?>
					</div>

				</div>
			<?php endforeach; ?>
			</div><!-- .qae-grid -->

			<p class="qae-footer-note">
				<?php
				esc_html_e( 'All Qaiyo plugins are built by', 'qaiyo-access-manager' );
				echo ' <a href="https://qaiyo-plugins.com" target="_blank" rel="noopener noreferrer">Qaiyo by PixelDesigns</a>. ';
				// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped — static URL only.
				esc_html_e( 'Need help? Contact us at', 'qaiyo-access-manager' );
				echo ' <a href="mailto:info@qaiyo-plugins.com">info@qaiyo-plugins.com</a>.';
				// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped — static mailto.
				?>
			</p>
		</div>
		<?php
	}
}
