<?php
/**
 * Frontend content protection shortcode.
 *
 *   [qaiyo_protect role="editor,shop_manager"]...[/qaiyo_protect]
 *   [qaiyo_protect deny="subscriber"]...[/qaiyo_protect]
 *   [qaiyo_protect logged_in="yes"]...[/qaiyo_protect]
 *   [qaiyo_protect cap="manage_woocommerce" message="No access."]...[/qaiyo_protect]
 *
 * Attributes (all optional, combined with AND):
 *   role      Comma-separated allow list of role slugs.
 *   deny      Comma-separated deny list of role slugs.
 *   logged_in "yes" requires a logged-in user, "no" requires a guest.
 *   cap       Required capability.
 *   message   Text shown instead of the content when access is denied.
 *
 * @package qaiyo-access-manager
 */

defined( 'ABSPATH' ) || exit;

class Qaiyo_Access_Manager_Shortcodes {

	public static function init() {
		add_shortcode( 'qaiyo_protect', array( __CLASS__, 'render_protect' ) );
	}

	public static function render_protect( $atts, $content = '' ) {
		$atts = shortcode_atts(
			array(
				'role'      => '',
				'deny'      => '',
				'logged_in' => '',
				'cap'       => '',
				'message'   => '',
			),
			$atts,
			'qaiyo_protect'
		);

		if ( self::user_passes( $atts ) ) {
			// Allow nested shortcodes inside the protected block.
			return do_shortcode( $content );
		}

		return $atts['message'] ? wp_kses_post( $atts['message'] ) : '';
	}

	private static function user_passes( $atts ) {
		$user      = wp_get_current_user();
		$logged_in = is_user_logged_in();

		// logged_in gate.
		if ( '' !== $atts['logged_in'] ) {
			$want = in_array( strtolower( $atts['logged_in'] ), array( 'yes', '1', 'true' ), true );
			if ( $want !== $logged_in ) {
				return false;
			}
		}

		// Capability gate.
		if ( '' !== $atts['cap'] ) {
			if ( ! $logged_in || ! $user->has_cap( sanitize_key( $atts['cap'] ) ) ) {
				return false;
			}
		}

		$user_roles = $logged_in ? (array) $user->roles : array();

		// Allow list.
		if ( '' !== $atts['role'] ) {
			$allow = self::parse_list( $atts['role'] );
			if ( empty( array_intersect( $user_roles, $allow ) ) ) {
				return false;
			}
		}

		// Deny list.
		if ( '' !== $atts['deny'] ) {
			$deny = self::parse_list( $atts['deny'] );
			if ( ! empty( array_intersect( $user_roles, $deny ) ) ) {
				return false;
			}
		}

		return true;
	}

	private static function parse_list( $csv ) {
		$parts = array_map( 'trim', explode( ',', (string) $csv ) );
		$parts = array_map( 'sanitize_key', $parts );
		return array_filter( $parts );
	}
}
