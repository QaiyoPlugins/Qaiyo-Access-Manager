<?php
/**
 * Access enforcement for Qaiyo Access Manager: plugin list/menu/page filtering
 * and CPT enforcement (menu, meta caps, REST, queries, front end) + the
 * restricted-access admin notice.
 *
 * Split out of the main class as a trait; remains part of the
 * Qaiyo_Access_Manager class so all $this-> calls resolve unchanged.
 *
 * @package Qaiyo_Access_Manager
 */

defined( 'ABSPATH' ) || exit;

trait Qaiyo_Access_Manager_Enforcement {
	// =========================================================================
	// PLUGIN FILTERS
	// =========================================================================

	public function filter_plugins_list( $plugins ) {
		if ( current_user_can( 'manage_options' ) ) {
			return $plugins;
		}
		$filtered = array();
		foreach ( $plugins as $file => $data ) {
			if ( $file === QAIYO_ACCESS_MANAGER_PLUGIN_BASENAME ) {
				continue;
			}
			if ( $this->can_user_access_plugin( $file ) ) {
				$filtered[ $file ] = $data;
			}
		}
		return $filtered;
	}

	public function filter_plugin_action_links( $actions, $plugin_file, $plugin_data, $context ) {
		if ( current_user_can( 'manage_options' ) ) {
			return $actions;
		}
		if ( ! $this->can_user_access_plugin( $plugin_file ) ) {
			unset( $actions['activate'], $actions['deactivate'], $actions['delete'], $actions['edit'] );
		}
		return $actions;
	}

	// =========================================================================
	// PLUGIN PAGE ENFORCEMENT
	//
	// Hiding a plugin from the Plugins screen does NOT stop a user from using
	// the plugin: most plugins (Amelia, Fluent Forms, WooCommerce…) register
	// their own admin menu pages under their own capabilities, which our rules
	// never touched. This layer removes those menu pages and blocks direct URL
	// access for any plugin the current user is not allowed to access.
	//
	// Ownership of a menu page is resolved by reflecting on its render callback
	// and mapping the defining file back to a plugin folder — no slug guessing.
	// =========================================================================

	public function enforce_restricted_plugin_pages() {
		if ( current_user_can( 'manage_options' ) ) {
			return;
		}

		// Determine which installed plugins the user may NOT access. We check
		// every installed plugin (not just rule keys) so Pro group/temp rules
		// that target a plugin without a base role rule are still enforced.
		//
		// The "owner" token matches what plugin_folder_from_file() returns: a
		// foldered plugin maps to its folder, a single-file plugin to its own
		// filename — so single-file plugins are covered too.
		$restricted_owners = array();
		foreach ( array_keys( $this->get_manageable_plugins() ) as $plugin_file ) {
			if ( $this->can_user_access_plugin( $plugin_file ) ) {
				continue;
			}
			$dir   = dirname( $plugin_file );
			$owner = ( '.' === $dir || '' === $dir ) ? $plugin_file : $dir;
			if ( '' !== $owner ) {
				$restricted_owners[ $owner ] = true;
			}
		}
		if ( empty( $restricted_owners ) ) {
			return;
		}

		global $menu, $submenu;

		$top_to_remove    = array();
		$sub_to_remove    = array();
		$restricted_slugs = array();

		// Submenu pages (resolved against their real parent slug).
		if ( ! empty( $submenu ) && is_array( $submenu ) ) {
			foreach ( $submenu as $parent => $items ) {
				if ( ! is_array( $items ) ) {
					continue;
				}
				foreach ( $items as $item ) {
					if ( empty( $item[2] ) ) {
						continue;
					}
					$owner = $this->resolve_menu_owner_folder( $item[2], $parent );
					if ( '' !== $owner && isset( $restricted_owners[ $owner ] ) ) {
						$sub_to_remove[]                = array( $parent, $item[2] );
						$restricted_slugs[ $item[2] ]   = true;
					}
				}
			}
		}

		// Top-level pages.
		if ( ! empty( $menu ) && is_array( $menu ) ) {
			foreach ( $menu as $item ) {
				if ( empty( $item[2] ) ) {
					continue;
				}
				$owner = $this->resolve_menu_owner_folder( $item[2], '' );
				if ( '' !== $owner && isset( $restricted_owners[ $owner ] ) ) {
					$top_to_remove[]              = $item[2];
					$restricted_slugs[ $item[2] ] = true;
				}
			}
		}

		foreach ( $sub_to_remove as $pair ) {
			remove_submenu_page( $pair[0], $pair[1] );
		}
		foreach ( $top_to_remove as $slug ) {
			remove_menu_page( $slug );
		}

		// Removing a menu page only hides the link — it does not block a direct
		// hit on admin.php?page=SLUG. Deny access to any page we just identified.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only routing param, used solely to deny access.
		$current_page = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';
		$blocked      = '' !== $current_page && isset( $restricted_slugs[ $current_page ] );

		// Catch hidden subpages too (registered with no visible menu item), which
		// never appear in $menu/$submenu but are still reachable by direct URL.
		if ( ! $blocked && '' !== $current_page ) {
			$owner   = $this->resolve_menu_owner_folder( $current_page, '' );
			$blocked = '' !== $owner && isset( $restricted_owners[ $owner ] );
		}

		if ( $blocked ) {
			wp_die(
				esc_html__( 'You do not have permission to access this page.', 'qaiyo-access-manager' ),
				'',
				array(
					'response'  => 403,
					'back_link' => true,
				)
			);
		}
	}

	/**
	 * Resolve which plugin folder owns an admin page by reflecting on the
	 * page-render callback registered for its menu hook.
	 *
	 * @param string $slug   Menu or submenu slug.
	 * @param string $parent Parent slug ('' for a top-level page).
	 * @return string Plugin folder slug, or '' if not attributable to a plugin.
	 */
	private function resolve_menu_owner_folder( $slug, $parent = '' ) {
		// Reflection is comparatively expensive and the menu is stable within a
		// request, so memoize per parent|slug.
		$cache_key = $parent . '|' . $slug;
		if ( isset( $this->menu_owner_cache[ $cache_key ] ) ) {
			return $this->menu_owner_cache[ $cache_key ];
		}
		$this->menu_owner_cache[ $cache_key ] = '';

		if ( ! function_exists( 'get_plugin_page_hook' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$hook = get_plugin_page_hook( $slug, $parent );
		if ( ! $hook ) {
			return '';
		}
		if ( empty( $GLOBALS['wp_filter'][ $hook ] ) || empty( $GLOBALS['wp_filter'][ $hook ]->callbacks ) ) {
			return '';
		}
		foreach ( $GLOBALS['wp_filter'][ $hook ]->callbacks as $callbacks ) {
			foreach ( $callbacks as $cb ) {
				if ( ! isset( $cb['function'] ) ) {
					continue;
				}
				$file = $this->reflect_callback_file( $cb['function'] );
				if ( '' === $file ) {
					continue;
				}
				$folder = $this->plugin_folder_from_file( $file );
				if ( '' !== $folder ) {
					$this->menu_owner_cache[ $cache_key ] = $folder;
					return $folder;
				}
			}
		}
		return '';
	}

	/**
	 * Get the file in which a callback is defined, via reflection.
	 *
	 * @param mixed $fn Callable in any of the forms WordPress stores.
	 * @return string Absolute file path, or '' on failure.
	 */
	private function reflect_callback_file( $fn ) {
		try {
			if ( $fn instanceof Closure ) {
				$ref = new ReflectionFunction( $fn );
			} elseif ( is_string( $fn ) ) {
				if ( false !== strpos( $fn, '::' ) ) {
					list( $class, $method ) = explode( '::', $fn, 2 );
					$ref                    = new ReflectionMethod( $class, $method );
				} elseif ( function_exists( $fn ) ) {
					$ref = new ReflectionFunction( $fn );
				} else {
					return '';
				}
			} elseif ( is_array( $fn ) && isset( $fn[0], $fn[1] ) ) {
				$class = is_object( $fn[0] ) ? get_class( $fn[0] ) : $fn[0];
				$ref   = new ReflectionMethod( $class, $fn[1] );
			} else {
				return '';
			}
			$file = $ref->getFileName();
			return $file ? $file : '';
		} catch ( Throwable $e ) {
			return '';
		}
	}

	/**
	 * Map an absolute file path to the plugin folder that contains it.
	 *
	 * @param string $file Absolute path.
	 * @return string Plugin folder slug, or '' if the file is not inside a plugin.
	 */
	private function plugin_folder_from_file( $file ) {
		$plugins_dir = wp_normalize_path( WP_PLUGIN_DIR );
		$file        = wp_normalize_path( $file );
		if ( 0 !== strpos( $file, $plugins_dir . '/' ) ) {
			return '';
		}
		$relative = ltrim( substr( $file, strlen( $plugins_dir ) ), '/' );
		$folder   = strtok( $relative, '/' );
		return $folder ? $folder : '';
	}

	// =========================================================================
	// CPT FILTERS
	// =========================================================================

	public function filter_cpt_admin_menus() {
		if ( current_user_can( 'manage_options' ) ) {
			return;
		}
		$cpt_role_rules = $this->get_cpt_rules();
		$cpt_user_rules = $this->get_user_cpt_rules();
		$all_cpts       = array_unique( array_merge( array_keys( $cpt_role_rules ), array_keys( $cpt_user_rules ) ) );

		foreach ( $all_cpts as $post_type ) {
			if ( $this->can_user_access_cpt( $post_type ) ) {
				continue;
			}
			$type_obj = get_post_type_object( $post_type );
			if ( ! $type_obj ) {
				continue;
			}
			if ( true === $type_obj->show_in_menu ) {
				remove_menu_page( 'edit.php?post_type=' . $post_type );
			} elseif ( is_string( $type_obj->show_in_menu ) ) {
				remove_submenu_page( $type_obj->show_in_menu, 'edit.php?post_type=' . $post_type );
			}
		}
	}

	private $cpt_caps_map = null;

	private function build_cpt_caps_map() {
		if ( null !== $this->cpt_caps_map ) {
			return $this->cpt_caps_map;
		}
		$this->cpt_caps_map = array();
		$role_rules         = $this->get_cpt_rules();
		$user_rules         = $this->get_user_cpt_rules();
		$all_cpts           = array_unique( array_merge( array_keys( $role_rules ), array_keys( $user_rules ) ) );

		foreach ( $all_cpts as $post_type ) {
			$type_obj = get_post_type_object( $post_type );
			if ( ! $type_obj ) {
				continue;
			}
			// Only CPTs registered with their OWN capability set can be enforced
			// safely through map_meta_cap. A CPT that shares the core caps
			// (edit_posts, publish_posts…) would collide with posts, pages and
			// every other default-cap CPT — blocking or leaking unrelated
			// content. Those rely on the menu / query / REST / frontend layers.
			if ( ! $this->cpt_has_custom_caps( $type_obj ) ) {
				continue;
			}
			foreach ( (array) $type_obj->cap as $wp_cap ) {
				// Never map universal caps: 'read' gates the whole dashboard.
				if ( in_array( $wp_cap, array( 'do_not_allow', 'exist', 'read' ), true ) ) {
					continue;
				}
				$this->cpt_caps_map[ $wp_cap ][] = $post_type;
			}
		}
		foreach ( $this->cpt_caps_map as $wp_cap => $pts ) {
			$this->cpt_caps_map[ $wp_cap ] = array_values( array_unique( $pts ) );
		}
		return $this->cpt_caps_map;
	}

	/**
	 * Whether a post type was registered with its own custom capabilities rather
	 * than sharing the core post/page caps.
	 *
	 * @param WP_Post_Type $type_obj Post type object.
	 * @return bool
	 */
	private function cpt_has_custom_caps( $type_obj ) {
		$caps      = (array) $type_obj->cap;
		$edit_many = isset( $caps['edit_posts'] ) ? $caps['edit_posts'] : 'edit_posts';
		return ! in_array( $edit_many, array( 'edit_posts', 'edit_pages' ), true );
	}

	public function filter_cpt_meta_caps( $caps, $cap, $user_id, $args ) {
		$map = $this->build_cpt_caps_map();
		if ( ! isset( $map[ $cap ] ) ) {
			return $caps;
		}
		$post_types = $map[ $cap ];

		// When the check targets a specific object, resolve its real post type so
		// a custom cap shared by a few CPTs can't block an unrelated one.
		if ( isset( $args[0] ) && is_numeric( $args[0] ) ) {
			$obj_pt = get_post_type( (int) $args[0] );
			if ( $obj_pt && in_array( $obj_pt, $post_types, true ) ) {
				$post_types = array( $obj_pt );
			}
		}

		foreach ( $post_types as $post_type ) {
			if ( ! $this->can_user_access_cpt( $post_type, $user_id ) ) {
				return array( 'do_not_allow' );
			}
		}
		return $caps;
	}

	public function filter_cpt_rest_access( $result, $server, $request ) {
		if ( null !== $result ) {
			return $result;
		}
		if ( current_user_can( 'manage_options' ) ) {
			return $result;
		}
		$route      = $request->get_route();
		$role_rules = $this->get_cpt_rules();
		$user_rules = $this->get_user_cpt_rules();
		$all_cpts   = array_unique( array_merge( array_keys( $role_rules ), array_keys( $user_rules ) ) );

		foreach ( $all_cpts as $post_type ) {
			$type_obj = get_post_type_object( $post_type );
			if ( ! $type_obj || ! $type_obj->show_in_rest ) {
				continue;
			}
			$rest_base = ! empty( $type_obj->rest_base ) ? $type_obj->rest_base : $post_type;
			if ( preg_match( '#^/wp/v2/' . preg_quote( $rest_base, '#' ) . '(/|$)#', $route ) ) {
				if ( ! $this->can_user_access_cpt( $post_type ) ) {
					return new WP_Error(
						'wpam_rest_forbidden',
						__( 'You do not have permission to access this content type.', 'qaiyo-access-manager' ),
						array( 'status' => 403 )
					);
				}
			}
		}
		return $result;
	}

	public function filter_cpt_queries( $query ) {
		if ( current_user_can( 'manage_options' ) ) {
			return;
		}
		$post_type = $query->get( 'post_type' );
		if ( empty( $post_type ) ) {
			return;
		}
		$types = is_array( $post_type ) ? $post_type : array( $post_type );
		foreach ( $types as $type ) {
			if ( ! $this->can_user_access_cpt( $type ) ) {
				$query->set( 'post_type', '' );
				$query->set( 'post__in', array( 0 ) );
				return;
			}
		}
	}

	public function filter_cpt_frontend_access() {
		if ( current_user_can( 'manage_options' ) || ! is_singular() ) {
			return;
		}
		$post_type = get_post_type();
		if ( ! $post_type ) {
			return;
		}
		if ( $this->can_user_access_cpt( $post_type ) ) {
			return;
		}

		// Guests and logged-in-but-restricted users follow the same configured
		// policy below. The 'login' type calls auth_redirect(), which already
		// sends a logged-out visitor to the login screen.
		$type = Qaiyo_Access_Manager_Options::get( 'cpt_redirect_type', 'home' );

		if ( '404' === $type ) {
			global $wp_query;
			$wp_query->set_404();
			status_header( 404 );
			nocache_headers();
			return;
		}
		if ( 'login' === $type ) {
			auth_redirect();
			return;
		}
		if ( 'custom' === $type ) {
			$url = (string) Qaiyo_Access_Manager_Options::get( 'cpt_redirect_url', '' );
			if ( $url ) {
				wp_safe_redirect( $url );
				exit;
			}
		}

		wp_safe_redirect( home_url() );
		exit;
	}

	// =========================================================================
	// ADMIN NOTICE
	// =========================================================================

	public function restricted_notice() {
		$screen = get_current_screen();
		if ( ! $screen || 'plugins' !== $screen->id || current_user_can( 'manage_options' ) ) {
			return;
		}
		$has_any = ! empty( $this->get_plugin_rules() ) || ! empty( $this->get_user_plugin_rules() );
		if ( ! $has_any ) {
			return;
		}

		$type = Qaiyo_Access_Manager_Options::get( 'restricted_notice_type', 'info' );
		if ( 'none' === $type ) {
			return;
		}

		$custom = (string) Qaiyo_Access_Manager_Options::get( 'restricted_notice_message', '' );
		if ( '' !== trim( $custom ) ) {
			$user    = wp_get_current_user();
			$message = strtr(
				$custom,
				array(
					'{user_name}'   => $user ? $user->display_name : '',
					'{site_name}'   => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
					'{admin_email}' => get_option( 'admin_email' ),
				)
			);
		} else {
			$message = __( 'Some plugins are hidden because your access is restricted. Contact your administrator for more access.', 'qaiyo-access-manager' );
		}

		$class = 'notice-info';
		if ( 'warning' === $type ) {
			$class = 'notice-warning';
		} elseif ( 'error' === $type ) {
			$class = 'notice-error';
		}

		printf(
			'<div class="notice %1$s"><p>%2$s</p></div>',
			esc_attr( $class ),
			esc_html( $message )
		);
	}

}
