<?php
/**
 * Login redirect by role.
 *
 * After login, sends a user to the URL configured for their (primary) role
 * in the Options tab. Administrators are never redirected by this module
 * unless an explicit URL is set for the administrator-equivalent role.
 *
 * @package qaiyo-access-manager
 */

defined( 'ABSPATH' ) || exit;

class Qaiyo_Access_Manager_Login_Redirect {

	public static function init() {
		add_filter( 'login_redirect', array( __CLASS__, 'filter_redirect' ), 20, 3 );
	}

	/**
	 * @param string           $redirect_to Default destination.
	 * @param string           $requested   Requested redirect_to.
	 * @param WP_User|WP_Error $user        Logged-in user (or error).
	 */
	public static function filter_redirect( $redirect_to, $requested, $user ) {
		if ( ! ( $user instanceof WP_User ) || empty( $user->roles ) ) {
			return $redirect_to;
		}

		$map = Qaiyo_Access_Manager_Options::get( 'login_redirects', array() );
		if ( empty( $map ) || ! is_array( $map ) ) {
			return $redirect_to;
		}

		// Respect an explicit deep-link request (e.g. ?redirect_to=...) unless it
		// is just the default admin URL.
		foreach ( (array) $user->roles as $role ) {
			if ( ! empty( $map[ $role ] ) ) {
				return $map[ $role ];
			}
		}

		return $redirect_to;
	}
}
