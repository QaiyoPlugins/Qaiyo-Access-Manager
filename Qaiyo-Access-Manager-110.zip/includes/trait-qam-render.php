<?php
/**
 * Admin rendering for Qaiyo Access Manager: dashboard summary widget and the
 * settings page (plugins/CPT cards, matrix tab, tools tab).
 *
 * Split out of the main class as a trait to keep the markup-heavy rendering in
 * its own file. It remains part of the Qaiyo_Access_Manager class, so every
 * $this-> call resolves exactly as before.
 *
 * @package Qaiyo_Access_Manager
 */

defined( 'ABSPATH' ) || exit;

trait Qaiyo_Access_Manager_Render {
	// =========================================================================
	// DASHBOARD WIDGET
	// =========================================================================

	public function register_dashboard_widget() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		wp_add_dashboard_widget(
			'wpam_dashboard_widget',
			__( 'Qaiyo Access Manager', 'qaiyo-access-manager' ),
			array( $this, 'render_dashboard_widget' )
		);
	}

	public function render_dashboard_widget() {
		$plugin_rules = $this->get_plugin_rules();
		$cpt_rules    = $this->get_cpt_rules();
		$user_p_rules = $this->get_user_plugin_rules();
		$user_c_rules = $this->get_user_cpt_rules();

		$restricted_plugins = count( $plugin_rules );
		$restricted_cpts    = count( $cpt_rules );

		$user_override_count = 0;
		foreach ( $user_p_rules as $item_rules ) {
			$user_override_count += count( $item_rules['allowed'] ?? array() );
			$user_override_count += count( $item_rules['denied'] ?? array() );
		}
		foreach ( $user_c_rules as $item_rules ) {
			$user_override_count += count( $item_rules['allowed'] ?? array() );
			$user_override_count += count( $item_rules['denied'] ?? array() );
		}

		$total_rules = $restricted_plugins + $restricted_cpts;
		?>
		<div class="wpam-dashboard-widget">
			<div class="wpam-dw-stats">
				<div class="wpam-dw-stat">
					<span class="wpam-dw-stat-number"><?php echo esc_html( $restricted_plugins ); ?></span>
					<span class="wpam-dw-stat-label"><?php esc_html_e( 'Restricted plugins', 'qaiyo-access-manager' ); ?></span>
				</div>
				<div class="wpam-dw-stat">
					<span class="wpam-dw-stat-number"><?php echo esc_html( $restricted_cpts ); ?></span>
					<span class="wpam-dw-stat-label"><?php esc_html_e( 'Restricted CPTs', 'qaiyo-access-manager' ); ?></span>
				</div>
				<div class="wpam-dw-stat">
					<span class="wpam-dw-stat-number"><?php echo esc_html( $user_override_count ); ?></span>
					<span class="wpam-dw-stat-label"><?php esc_html_e( 'User overrides', 'qaiyo-access-manager' ); ?></span>
				</div>
			</div>

			<?php if ( 0 === $total_rules ) : ?>
				<p class="wpam-dw-empty"><?php esc_html_e( 'No access rules configured yet.', 'qaiyo-access-manager' ); ?></p>
			<?php endif; ?>

			<p class="wpam-dw-link">
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=qaiyo-access-manager' ) ); ?>" class="button button-primary">
					<?php esc_html_e( 'Manage access rules', 'qaiyo-access-manager' ); ?>
				</a>
			</p>
		</div>
		<?php
	}

	/**
	 * CSS for the dashboard widget. Enqueued via wp_add_inline_style() on the
	 * dashboard screen (see enqueue_admin_assets).
	 */
	private function dashboard_widget_css() {
		return '
			.wpam-dw-stats { display: flex; gap: 12px; margin-bottom: 12px; }
			.wpam-dw-stat { flex: 1; text-align: center; background: #f8f6ff; border: 1px solid #e2dcf7; border-radius: 4px; padding: 12px 8px; }
			.wpam-dw-stat-number { display: block; font-size: 24px; font-weight: 700; color: #6c5ce7; line-height: 1.2; }
			.wpam-dw-stat-label { display: block; font-size: 11px; color: #787c82; margin-top: 4px; }
			.wpam-dw-empty { color: #787c82; text-align: center; font-style: italic; }
			.wpam-dw-link { text-align: center; margin: 0; }
			.wpam-dw-link .button-primary { background: #6c5ce7; border-color: #5a4bd1; }
			.wpam-dw-link .button-primary:hover { background: #5a4bd1; }';
	}

	// =========================================================================
	// SETTINGS PAGE RENDER
	// =========================================================================

	/**
	 * Prime the WordPress user cache for every user referenced by an override
	 * rule, in a single query, so the per-row get_userdata() calls during card
	 * rendering hit the cache instead of issuing one query each.
	 *
	 * @param array $plugin_user_rules Plugin user-override rules.
	 * @param array $cpt_user_rules    CPT user-override rules.
	 */
	private function prime_override_user_cache( $plugin_user_rules, $cpt_user_rules ) {
		$ids = array();
		foreach ( array( $plugin_user_rules, $cpt_user_rules ) as $rule_set ) {
			if ( ! is_array( $rule_set ) ) {
				continue;
			}
			foreach ( $rule_set as $rule ) {
				$ids = array_merge( $ids, (array) ( $rule['allowed'] ?? array() ), (array) ( $rule['denied'] ?? array() ) );
			}
		}
		$ids = array_values( array_unique( array_map( 'intval', $ids ) ) );
		if ( ! empty( $ids ) ) {
			cache_users( $ids );
		}
	}

	public function render_settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'qaiyo-access-manager' ) );
		}

		$plugins            = $this->get_manageable_plugins();
		$cpts               = $this->get_custom_post_types();
		$roles              = $this->get_editable_roles();
		$plugin_role_rules  = $this->get_plugin_rules();
		$cpt_role_rules     = $this->get_cpt_rules();
		$plugin_user_rules  = $this->get_user_plugin_rules();
		$cpt_user_rules     = $this->get_user_cpt_rules();
		$native_plugin_info = $this->get_plugin_native_caps_info();

		// Prime the user cache in one query so the per-override get_userdata()
		// calls in the plugin/CPT cards don't fan out into N+1 queries.
		$this->prime_override_user_cache( $plugin_user_rules, $cpt_user_rules );

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only tab navigation, no data is processed.
		$active_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'plugins';
		/**
		 * Pro hook: allow additional valid tab slugs.
		 */
		$valid_tabs = apply_filters( 'qaiyo_access_manager_valid_tabs', array( 'plugins', 'cpt', 'matrix', 'capabilities', 'options', 'tools' ) );
		if ( ! in_array( $active_tab, $valid_tabs, true ) ) {
			$active_tab = 'plugins';
		}

		?>
		<div class="wrap wpam-wrap">
			<h1>
				<span class="wpam-brand">Qaiyo</span>
				<?php esc_html_e( 'Access Manager', 'qaiyo-access-manager' ); ?>
				<span class="wpam-version">v<?php echo esc_html( QAIYO_ACCESS_MANAGER_VERSION ); ?></span>
			</h1>
			<p class="wpam-description">
				<?php esc_html_e( 'Control plugin and content type access at role and user level. Administrators always have full access.', 'qaiyo-access-manager' ); ?>
			</p>

			<nav class="nav-tab-wrapper wpam-tabs">
				<a href="<?php echo esc_url( add_query_arg( 'tab', 'plugins', admin_url( 'admin.php?page=qaiyo-access-manager' ) ) ); ?>"
				   class="nav-tab <?php echo 'plugins' === $active_tab ? 'nav-tab-active' : ''; ?>">
					<?php esc_html_e( 'Plugins', 'qaiyo-access-manager' ); ?>
					<span class="wpam-tab-count"><?php echo count( $plugins ); ?></span>
				</a>
				<a href="<?php echo esc_url( add_query_arg( 'tab', 'cpt', admin_url( 'admin.php?page=qaiyo-access-manager' ) ) ); ?>"
				   class="nav-tab <?php echo 'cpt' === $active_tab ? 'nav-tab-active' : ''; ?>">
					<?php esc_html_e( 'Content Types (CPT)', 'qaiyo-access-manager' ); ?>
					<span class="wpam-tab-count"><?php echo count( $cpts ); ?></span>
				</a>
				<a href="<?php echo esc_url( add_query_arg( 'tab', 'matrix', admin_url( 'admin.php?page=qaiyo-access-manager' ) ) ); ?>"
				   class="nav-tab <?php echo 'matrix' === $active_tab ? 'nav-tab-active' : ''; ?>">
					<?php esc_html_e( 'Access Matrix', 'qaiyo-access-manager' ); ?>
				</a>
				<a href="<?php echo esc_url( add_query_arg( 'tab', 'capabilities', admin_url( 'admin.php?page=qaiyo-access-manager' ) ) ); ?>"
				   class="nav-tab <?php echo 'capabilities' === $active_tab ? 'nav-tab-active' : ''; ?>">
					<?php esc_html_e( 'Capabilities', 'qaiyo-access-manager' ); ?>
				</a>
				<a href="<?php echo esc_url( add_query_arg( 'tab', 'options', admin_url( 'admin.php?page=qaiyo-access-manager' ) ) ); ?>"
				   class="nav-tab <?php echo 'options' === $active_tab ? 'nav-tab-active' : ''; ?>">
					<?php esc_html_e( 'Options', 'qaiyo-access-manager' ); ?>
				</a>
				<a href="<?php echo esc_url( add_query_arg( 'tab', 'tools', admin_url( 'admin.php?page=qaiyo-access-manager' ) ) ); ?>"
				   class="nav-tab <?php echo 'tools' === $active_tab ? 'nav-tab-active' : ''; ?>">
					<?php esc_html_e( 'Tools', 'qaiyo-access-manager' ); ?>
				</a>
				<?php
				/**
				 * Pro hook: additional tabs in the nav.
				 *
				 * @param string $active_tab Current active tab slug.
				 */
				if ( has_action( 'qaiyo_access_manager_after_tabs' ) ) :
					?>
					<span class="wpam-tabs-divider" aria-hidden="true"></span>
					<?php
					do_action( 'qaiyo_access_manager_after_tabs', $active_tab );
				endif;

				// Pro upsell tab (only when Pro is not active). Rendered AFTER Pro's own
				// after_tabs so an installed-but-unlicensed Pro shows its own locked tab.
				Qaiyo_Access_Manager_Pro_Teaser::render_nav_link( $active_tab );
				?>
			</nav>

			<?php
			$hide_toolbar_tabs = apply_filters( 'qaiyo_access_manager_hide_toolbar_tabs', array( 'matrix', 'tools', 'capabilities', 'options' ) );
			?>
			<div class="wpam-toolbar" <?php echo in_array( $active_tab, $hide_toolbar_tabs, true ) ? 'style="display:none;"' : ''; ?>>
				<div class="wpam-search-box">
					<input type="text" id="wpam-search" placeholder="<?php esc_attr_e( 'Search...', 'qaiyo-access-manager' ); ?>" />
				</div>
				<div class="wpam-actions">
					<?php do_action( 'qaiyo_access_manager_toolbar_actions', $active_tab ); ?>
					<button type="button" class="button" id="wpam-expand-all"><?php esc_html_e( 'Expand all', 'qaiyo-access-manager' ); ?></button>
					<button type="button" class="button" id="wpam-collapse-all"><?php esc_html_e( 'Collapse all', 'qaiyo-access-manager' ); ?></button>
				</div>
			</div>

			<form id="wpam-access-form" method="post" data-active-tab="<?php echo esc_attr( $active_tab ); ?>">
				<?php wp_nonce_field( 'wpam_save_access_nonce', 'wpam_nonce' ); ?>

				<!-- PLUGINS TAB -->
				<div class="wpam-tab-content" id="wpam-tab-plugins" <?php echo 'plugins' !== $active_tab ? 'style="display:none;"' : ''; ?>>
					<div class="wpam-items-list">
						<?php if ( empty( $plugins ) ) : ?>
							<div class="wpam-empty"><?php esc_html_e( 'No plugins installed to manage.', 'qaiyo-access-manager' ); ?></div>
						<?php else : ?>
							<?php foreach ( $plugins as $plugin_file => $plugin_data ) :
								$p_rule    = $this->normalize_role_rule( $plugin_role_rules[ $plugin_file ] ?? null );
								$p_roles   = $p_rule['roles'];
								$p_mode    = $p_rule['mode'];
								$p_users   = $plugin_user_rules[ $plugin_file ] ?? array( 'allowed' => array(), 'denied' => array() );
								$is_active = is_plugin_active( $plugin_file );
								$has_rules = ! empty( $p_roles ) || ! empty( $p_users['allowed'] ) || ! empty( $p_users['denied'] );
							?>
								<div class="wpam-card <?php echo $is_active ? 'wpam-active' : 'wpam-inactive'; ?> <?php echo $has_rules ? 'wpam-has-rules' : ''; ?>"
									 data-item-type="plugin"
									 data-item-key="<?php echo esc_attr( $plugin_file ); ?>"
									 data-item-name="<?php echo esc_attr( strtolower( $plugin_data['Name'] ) ); ?>">

									<div class="wpam-card-header">
										<div class="wpam-card-info">
											<h3 class="wpam-card-title">
												<?php echo esc_html( $plugin_data['Name'] ); ?>
												<span class="wpam-card-version"><?php echo esc_html( $plugin_data['Version'] ); ?></span>
											</h3>
											<span class="wpam-badge <?php echo $is_active ? 'wpam-badge-active' : 'wpam-badge-inactive'; ?>">
												<?php echo $is_active ? esc_html__( 'Active', 'qaiyo-access-manager' ) : esc_html__( 'Inactive', 'qaiyo-access-manager' ); ?>
											</span>
											<?php if ( $has_rules ) : ?>
												<span class="wpam-badge wpam-badge-restricted"><?php esc_html_e( 'Restricted', 'qaiyo-access-manager' ); ?></span>
											<?php endif; ?>
										</div>
										<button type="button" class="wpam-toggle-btn" aria-expanded="false">
											<span class="dashicons dashicons-arrow-down-alt2"></span>
										</button>
									</div>

									<div class="wpam-card-body" style="display:none;">
										<?php if ( ! empty( $plugin_data['Description'] ) ) : ?>
											<p class="wpam-card-desc"><?php echo esc_html( $plugin_data['Description'] ); ?></p>
										<?php endif; ?>

										<div class="wpam-native-caps">
											<h4><?php esc_html_e( 'Default WordPress Capabilities', 'qaiyo-access-manager' ); ?></h4>
											<div class="wpam-native-caps-grid">
												<?php foreach ( $native_plugin_info as $cap_key => $cap_info ) : ?>
													<div class="wpam-native-cap-item">
														<span class="wpam-native-cap-label"><?php echo esc_html( $cap_info['label'] ); ?>:</span>
														<span class="wpam-native-cap-roles"><?php echo esc_html( implode( ', ', $cap_info['roles'] ) ); ?></span>
													</div>
												<?php endforeach; ?>
											</div>
										</div>

										<div class="wpam-section wpam-role-section" data-mode="<?php echo esc_attr( $p_mode ); ?>">
											<h4><?php esc_html_e( 'Role-based access', 'qaiyo-access-manager' ); ?></h4>
											<p class="wpam-hint"><?php esc_html_e( 'If no role is selected, the item remains accessible to everyone.', 'qaiyo-access-manager' ); ?></p>

											<div class="wpam-mode-toggle" role="radiogroup" aria-label="<?php esc_attr_e( 'Rule mode', 'qaiyo-access-manager' ); ?>">
												<label class="wpam-mode-option <?php echo 'allow' === $p_mode ? 'wpam-mode-active' : ''; ?>">
													<input type="radio" class="wpam-mode-radio" name="mode_<?php echo esc_attr( md5( $plugin_file ) ); ?>" value="allow" <?php checked( $p_mode, 'allow' ); ?> />
													<span class="wpam-mode-label"><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e( 'Allow only checked roles', 'qaiyo-access-manager' ); ?></span>
												</label>
												<label class="wpam-mode-option <?php echo 'deny' === $p_mode ? 'wpam-mode-active' : ''; ?>">
													<input type="radio" class="wpam-mode-radio" name="mode_<?php echo esc_attr( md5( $plugin_file ) ); ?>" value="deny" <?php checked( $p_mode, 'deny' ); ?> />
													<span class="wpam-mode-label"><span class="dashicons dashicons-dismiss"></span> <?php esc_html_e( 'Deny checked roles', 'qaiyo-access-manager' ); ?></span>
												</label>
											</div>
											<p class="wpam-hint wpam-mode-explainer">
												<span class="wpam-mode-explain-allow"><?php esc_html_e( 'Only users with a checked role can see this plugin on the Plugins page (admins always have access).', 'qaiyo-access-manager' ); ?></span>
												<span class="wpam-mode-explain-deny"><?php esc_html_e( 'This plugin is hidden from users with a checked role; everyone else keeps access (admins always have access).', 'qaiyo-access-manager' ); ?></span>
											</p>

											<?php $this->render_role_grid( $roles, $p_roles, $plugin_file ); ?>
										</div>

										<?php $this->render_user_override_section( $p_users ); ?>
									</div>
								</div>
							<?php endforeach; ?>
						<?php endif; ?>
					</div>
				</div>

				<!-- CPT TAB -->
				<div class="wpam-tab-content" id="wpam-tab-cpt" <?php echo 'cpt' !== $active_tab ? 'style="display:none;"' : ''; ?>>
					<div class="wpam-items-list">
						<?php if ( empty( $cpts ) ) : ?>
							<div class="wpam-empty"><?php esc_html_e( 'No custom post types registered.', 'qaiyo-access-manager' ); ?></div>
						<?php else : ?>
							<?php foreach ( $cpts as $cpt_slug => $cpt_obj ) :
								$c_rule      = $this->normalize_role_rule( $cpt_role_rules[ $cpt_slug ] ?? null );
								$c_roles     = $c_rule['roles'];
								$c_mode      = $c_rule['mode'];
								$c_users     = $cpt_user_rules[ $cpt_slug ] ?? array( 'allowed' => array(), 'denied' => array() );
								$has_rules   = ! empty( $c_roles ) || ! empty( $c_users['allowed'] ) || ! empty( $c_users['denied'] );
								$native_info = $this->get_cpt_native_caps_info( $cpt_obj );
							?>
								<div class="wpam-card wpam-cpt-card <?php echo $has_rules ? 'wpam-has-rules' : ''; ?>"
									 data-item-type="cpt"
									 data-item-key="<?php echo esc_attr( $cpt_slug ); ?>"
									 data-item-name="<?php echo esc_attr( strtolower( $cpt_obj->labels->name ) ); ?>">

									<div class="wpam-card-header">
										<div class="wpam-card-info">
											<h3 class="wpam-card-title">
												<?php echo esc_html( $cpt_obj->labels->name ); ?>
												<span class="wpam-card-version"><?php echo esc_html( $cpt_slug ); ?></span>
											</h3>
											<span class="wpam-badge wpam-badge-cpt">CPT</span>
											<?php if ( $cpt_obj->public ) : ?>
												<span class="wpam-badge wpam-badge-active"><?php esc_html_e( 'Public', 'qaiyo-access-manager' ); ?></span>
											<?php endif; ?>
											<?php if ( $cpt_obj->show_in_rest ) : ?>
												<span class="wpam-badge wpam-badge-rest">REST</span>
											<?php endif; ?>
											<?php if ( $has_rules ) : ?>
												<span class="wpam-badge wpam-badge-restricted"><?php esc_html_e( 'Restricted', 'qaiyo-access-manager' ); ?></span>
											<?php endif; ?>
										</div>
										<button type="button" class="wpam-toggle-btn" aria-expanded="false">
											<span class="dashicons dashicons-arrow-down-alt2"></span>
										</button>
									</div>

									<div class="wpam-card-body" style="display:none;">
										<?php if ( $cpt_obj->description ) : ?>
											<p class="wpam-card-desc"><?php echo esc_html( $cpt_obj->description ); ?></p>
										<?php endif; ?>

										<div class="wpam-cpt-meta">
											<span><strong>Slug:</strong> <code><?php echo esc_html( $cpt_slug ); ?></code></span>
											<span><strong><?php esc_html_e( 'Singular:', 'qaiyo-access-manager' ); ?></strong> <?php echo esc_html( $cpt_obj->labels->singular_name ); ?></span>
											<?php if ( $cpt_obj->has_archive ) : ?>
												<span><strong><?php esc_html_e( 'Archive:', 'qaiyo-access-manager' ); ?></strong> <?php esc_html_e( 'Yes', 'qaiyo-access-manager' ); ?></span>
											<?php endif; ?>
										</div>

										<?php if ( ! empty( $native_info ) ) : ?>
										<div class="wpam-native-caps">
											<h4><?php esc_html_e( 'Default WordPress Capabilities', 'qaiyo-access-manager' ); ?></h4>
											<div class="wpam-native-caps-grid">
												<?php foreach ( $native_info as $cap_info ) : ?>
													<div class="wpam-native-cap-item">
														<span class="wpam-native-cap-label"><?php echo esc_html( $cap_info['label'] ); ?>:</span>
														<span class="wpam-native-cap-roles"><?php echo esc_html( implode( ', ', $cap_info['roles'] ) ); ?></span>
														<code class="wpam-native-cap-code"><?php echo esc_html( $cap_info['wp_cap'] ); ?></code>
													</div>
												<?php endforeach; ?>
											</div>
										</div>
										<?php endif; ?>

										<div class="wpam-section wpam-role-section" data-mode="<?php echo esc_attr( $c_mode ); ?>">
											<h4><?php esc_html_e( 'Role-based access', 'qaiyo-access-manager' ); ?></h4>
											<p class="wpam-hint"><?php esc_html_e( 'If no role is selected, the item remains accessible to everyone.', 'qaiyo-access-manager' ); ?></p>

											<div class="wpam-mode-toggle" role="radiogroup" aria-label="<?php esc_attr_e( 'Rule mode', 'qaiyo-access-manager' ); ?>">
												<label class="wpam-mode-option <?php echo 'allow' === $c_mode ? 'wpam-mode-active' : ''; ?>">
													<input type="radio" class="wpam-mode-radio" name="mode_<?php echo esc_attr( md5( $cpt_slug ) ); ?>" value="allow" <?php checked( $c_mode, 'allow' ); ?> />
													<span class="wpam-mode-label"><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e( 'Allow only checked roles', 'qaiyo-access-manager' ); ?></span>
												</label>
												<label class="wpam-mode-option <?php echo 'deny' === $c_mode ? 'wpam-mode-active' : ''; ?>">
													<input type="radio" class="wpam-mode-radio" name="mode_<?php echo esc_attr( md5( $cpt_slug ) ); ?>" value="deny" <?php checked( $c_mode, 'deny' ); ?> />
													<span class="wpam-mode-label"><span class="dashicons dashicons-dismiss"></span> <?php esc_html_e( 'Deny checked roles', 'qaiyo-access-manager' ); ?></span>
												</label>
											</div>
											<p class="wpam-hint wpam-mode-explainer">
												<span class="wpam-mode-explain-allow"><?php esc_html_e( 'Only users with a checked role can access this content type (admins always have access). Affects the admin menu, REST API and frontend.', 'qaiyo-access-manager' ); ?></span>
												<span class="wpam-mode-explain-deny"><?php esc_html_e( 'Users with a checked role lose access to this content type; everyone else keeps it (admins always have access). Affects the admin menu, REST API and frontend.', 'qaiyo-access-manager' ); ?></span>
											</p>

											<?php $this->render_role_grid( $roles, $c_roles, $cpt_slug ); ?>
										</div>

										<?php $this->render_user_override_section( $c_users ); ?>
									</div>
								</div>
							<?php endforeach; ?>
						<?php endif; ?>
					</div>
				</div>

				<div class="wpam-submit-bar" <?php echo in_array( $active_tab, $hide_toolbar_tabs, true ) ? 'style="display:none;"' : ''; ?>>
					<button type="submit" class="button button-primary button-hero" id="wpam-save-btn">
						<?php esc_html_e( 'Save settings', 'qaiyo-access-manager' ); ?>
					</button>
					<span class="wpam-save-status" id="wpam-save-status"></span>
				</div>
			</form>

			<?php if ( 'matrix' === $active_tab ) : ?>
				<?php
				/**
				 * Pro hook: replace the read-only matrix with an editable one.
				 *
				 * @param bool $handled If true, the default read-only matrix is skipped.
				 */
				$matrix_handled = apply_filters( 'qaiyo_access_manager_render_matrix', false, $plugins, $cpts, $roles, $plugin_role_rules, $cpt_role_rules );
				if ( ! $matrix_handled ) :
				?>
				<?php $this->render_matrix_tab( $plugins, $cpts, $roles, $plugin_role_rules, $cpt_role_rules ); ?>
				<?php endif; ?>
			<?php endif; ?>

			<?php if ( 'capabilities' === $active_tab ) : ?>
				<?php Qaiyo_Access_Manager_Capabilities_Viewer::render(); ?>
			<?php endif; ?>

			<?php if ( 'options' === $active_tab ) : ?>
				<?php Qaiyo_Access_Manager_Options::render(); ?>
			<?php endif; ?>

			<?php if ( 'tools' === $active_tab ) : ?>
				<?php $this->render_tools_tab(); ?>
				<?php Qaiyo_Access_Manager_Pro_Teaser::render_tools_teaser(); ?>
			<?php endif; ?>

			<?php if ( 'pro' === $active_tab ) : ?>
				<?php Qaiyo_Access_Manager_Pro_Teaser::render_showcase(); ?>
			<?php endif; ?>

			<?php
			/**
			 * Pro hook: render content for Pro-added tabs (presets, groups, etc.)
			 */
			do_action( 'qaiyo_access_manager_render_tab_content', $active_tab, $plugins, $cpts, $roles, $plugin_role_rules, $cpt_role_rules );
			?>

			<div class="wpam-footer">
				<p>
					<?php
					printf(
						/* translators: %s: version number */
						esc_html__( 'Qaiyo Access Manager v%s — Qaiyo by PixelDesigns', 'qaiyo-access-manager' ),
						esc_html( QAIYO_ACCESS_MANAGER_VERSION )
					);
					?>
				</p>
			</div>
		</div>
		<?php
	}

	// =========================================================================
	// MATRIX TAB
	// =========================================================================

	private function render_matrix_tab( $plugins, $cpts, $roles, $plugin_role_rules, $cpt_role_rules ) {
		$role_names = array();
		foreach ( $roles as $slug => $data ) {
			$role_names[ $slug ] = translate_user_role( $data['name'] );
		}
		?>
		<div class="wpam-matrix-wrap">
			<?php Qaiyo_Access_Manager_Pro_Teaser::render_matrix_banner(); ?>

			<h3><?php esc_html_e( 'Plugin access by role', 'qaiyo-access-manager' ); ?></h3>
			<?php if ( empty( $plugins ) ) : ?>
				<p class="wpam-empty"><?php esc_html_e( 'No plugins installed to manage.', 'qaiyo-access-manager' ); ?></p>
			<?php else : ?>
				<div class="wpam-matrix-scroll">
					<table class="wpam-matrix-table">
						<thead>
							<tr>
								<th class="wpam-matrix-item-col"><?php esc_html_e( 'Plugin', 'qaiyo-access-manager' ); ?></th>
								<?php foreach ( $role_names as $rname ) : ?>
									<th class="wpam-matrix-role-col"><?php echo esc_html( $rname ); ?></th>
								<?php endforeach; ?>
								<th class="wpam-matrix-status-col"><?php esc_html_e( 'Status', 'qaiyo-access-manager' ); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ( $plugins as $file => $pdata ) :
								$p_rule    = $this->normalize_role_rule( $plugin_role_rules[ $file ] ?? null );
								$p_roles   = $p_rule['roles'];
								$p_mode    = $p_rule['mode'];
								$has_rules = ! empty( $p_roles );
							?>
								<tr class="<?php echo $has_rules ? 'wpam-matrix-restricted' : ''; ?>">
									<td class="wpam-matrix-item-name">
										<?php echo esc_html( $pdata['Name'] ); ?>
									</td>
									<?php foreach ( array_keys( $role_names ) as $rslug ) :
										if ( ! $has_rules ) {
											$state = 'open';
										} else {
											$listed = in_array( $rslug, $p_roles, true );
											if ( 'deny' === $p_mode ) {
												$state = $listed ? 'denied' : 'allowed';
											} else {
												$state = $listed ? 'allowed' : 'denied';
											}
										}
									?>
										<td class="wpam-matrix-cell">
											<?php if ( 'open' === $state ) : ?>
												<span class="wpam-matrix-open" title="<?php esc_attr_e( 'Open', 'qaiyo-access-manager' ); ?>">&#9679;</span>
											<?php elseif ( 'allowed' === $state ) : ?>
												<span class="wpam-matrix-allowed" title="<?php esc_attr_e( 'Allowed', 'qaiyo-access-manager' ); ?>">&#10003;</span>
											<?php else : ?>
												<span class="wpam-matrix-denied" title="<?php esc_attr_e( 'Denied', 'qaiyo-access-manager' ); ?>">&#10005;</span>
											<?php endif; ?>
										</td>
									<?php endforeach; ?>
									<td class="wpam-matrix-cell">
										<?php if ( $has_rules ) : ?>
											<span class="wpam-badge wpam-badge-restricted">
												<?php echo 'deny' === $p_mode
													? esc_html__( 'Deny mode', 'qaiyo-access-manager' )
													: esc_html__( 'Allow mode', 'qaiyo-access-manager' ); ?>
											</span>
										<?php else : ?>
											<span class="wpam-badge wpam-badge-active"><?php esc_html_e( 'Open', 'qaiyo-access-manager' ); ?></span>
										<?php endif; ?>
									</td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			<?php endif; ?>

			<h3 style="margin-top: 24px;"><?php esc_html_e( 'Content type access by role', 'qaiyo-access-manager' ); ?></h3>
			<?php if ( empty( $cpts ) ) : ?>
				<p class="wpam-empty"><?php esc_html_e( 'No custom post types registered.', 'qaiyo-access-manager' ); ?></p>
			<?php else : ?>
				<div class="wpam-matrix-scroll">
					<table class="wpam-matrix-table">
						<thead>
							<tr>
								<th class="wpam-matrix-item-col"><?php esc_html_e( 'Content Type', 'qaiyo-access-manager' ); ?></th>
								<?php foreach ( $role_names as $rname ) : ?>
									<th class="wpam-matrix-role-col"><?php echo esc_html( $rname ); ?></th>
								<?php endforeach; ?>
								<th class="wpam-matrix-status-col"><?php esc_html_e( 'Status', 'qaiyo-access-manager' ); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ( $cpts as $cpt_slug => $cpt_obj ) :
								$c_rule    = $this->normalize_role_rule( $cpt_role_rules[ $cpt_slug ] ?? null );
								$c_roles   = $c_rule['roles'];
								$c_mode    = $c_rule['mode'];
								$has_rules = ! empty( $c_roles );
							?>
								<tr class="<?php echo $has_rules ? 'wpam-matrix-restricted' : ''; ?>">
									<td class="wpam-matrix-item-name">
										<?php echo esc_html( $cpt_obj->labels->name ); ?>
										<span class="wpam-matrix-slug"><?php echo esc_html( $cpt_slug ); ?></span>
									</td>
									<?php foreach ( array_keys( $role_names ) as $rslug ) :
										if ( ! $has_rules ) {
											$state = 'open';
										} else {
											$listed = in_array( $rslug, $c_roles, true );
											if ( 'deny' === $c_mode ) {
												$state = $listed ? 'denied' : 'allowed';
											} else {
												$state = $listed ? 'allowed' : 'denied';
											}
										}
									?>
										<td class="wpam-matrix-cell">
											<?php if ( 'open' === $state ) : ?>
												<span class="wpam-matrix-open" title="<?php esc_attr_e( 'Open', 'qaiyo-access-manager' ); ?>">&#9679;</span>
											<?php elseif ( 'allowed' === $state ) : ?>
												<span class="wpam-matrix-allowed" title="<?php esc_attr_e( 'Allowed', 'qaiyo-access-manager' ); ?>">&#10003;</span>
											<?php else : ?>
												<span class="wpam-matrix-denied" title="<?php esc_attr_e( 'Denied', 'qaiyo-access-manager' ); ?>">&#10005;</span>
											<?php endif; ?>
										</td>
									<?php endforeach; ?>
									<td class="wpam-matrix-cell">
										<?php if ( $has_rules ) : ?>
											<span class="wpam-badge wpam-badge-restricted">
												<?php echo 'deny' === $c_mode
													? esc_html__( 'Deny mode', 'qaiyo-access-manager' )
													: esc_html__( 'Allow mode', 'qaiyo-access-manager' ); ?>
											</span>
										<?php else : ?>
											<span class="wpam-badge wpam-badge-active"><?php esc_html_e( 'Open', 'qaiyo-access-manager' ); ?></span>
										<?php endif; ?>
									</td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			<?php endif; ?>

			<p class="wpam-matrix-hint">
				<span class="wpam-matrix-allowed">&#10003;</span> = <?php esc_html_e( 'Allowed', 'qaiyo-access-manager' ); ?> &nbsp;
				<span class="wpam-matrix-denied">&#10005;</span> = <?php esc_html_e( 'Denied', 'qaiyo-access-manager' ); ?> &nbsp;
				<span class="wpam-matrix-open">&#9679;</span> = <?php esc_html_e( 'Open (no restriction)', 'qaiyo-access-manager' ); ?>
			</p>
		</div>
		<?php
	}

	// =========================================================================
	// TOOLS TAB
	// =========================================================================

	private function render_tools_tab() {
		?>
		<div class="wpam-tools-wrap">
			<div class="wpam-tools-grid">

				<div class="wpam-tool-card">
					<h3>
						<span class="dashicons dashicons-download"></span>
						<?php esc_html_e( 'Export Settings', 'qaiyo-access-manager' ); ?>
					</h3>
					<p><?php esc_html_e( 'Download all access rules as a JSON file. Use this to create a backup or transfer settings to another site.', 'qaiyo-access-manager' ); ?></p>
					<button type="button" class="button button-primary wpam-icon-btn" id="wpam-export-btn">
						<span class="dashicons dashicons-download"></span>
						<?php esc_html_e( 'Export to JSON', 'qaiyo-access-manager' ); ?>
					</button>
					<span class="wpam-tool-status" id="wpam-export-status"></span>
				</div>

				<div class="wpam-tool-card">
					<h3>
						<span class="dashicons dashicons-upload"></span>
						<?php esc_html_e( 'Import Settings', 'qaiyo-access-manager' ); ?>
					</h3>
					<p><?php esc_html_e( 'Upload a previously exported JSON file to restore or apply access rules. This will overwrite current settings.', 'qaiyo-access-manager' ); ?></p>
					<div class="wpam-import-area">
						<input type="file" id="wpam-import-file" accept=".json" style="display:none;" />
						<label for="wpam-import-file" class="wpam-import-dropzone" id="wpam-import-dropzone">
							<span class="dashicons dashicons-upload"></span>
							<span><?php esc_html_e( 'Choose file or drag & drop', 'qaiyo-access-manager' ); ?></span>
							<span class="wpam-import-filetypes">.json</span>
						</label>
						<div class="wpam-import-file-info" id="wpam-import-file-info" style="display:none;">
							<span class="dashicons dashicons-media-text"></span>
							<span id="wpam-import-filename"></span>
							<button type="button" class="button button-small" id="wpam-import-clear">&times;</button>
						</div>
						<button type="button" class="button button-primary wpam-icon-btn" id="wpam-import-btn" disabled>
							<span class="dashicons dashicons-upload"></span>
							<?php esc_html_e( 'Import', 'qaiyo-access-manager' ); ?>
						</button>
						<span class="wpam-tool-status" id="wpam-import-status"></span>
					</div>
				</div>

			</div>

			<div class="wpam-tool-card wpam-tool-card-full">
				<h3>
					<span class="dashicons dashicons-trash"></span>
					<?php esc_html_e( 'Uninstall behavior', 'qaiyo-access-manager' ); ?>
				</h3>
				<p><?php esc_html_e( 'Choose what happens when you delete this plugin from the Plugins page.', 'qaiyo-access-manager' ); ?></p>
				<label class="wpam-uninstall-toggle">
					<input type="checkbox" id="wpam-delete-data" <?php checked( get_option( 'wpam_delete_data_on_uninstall', false ) ); ?> />
					<span><?php esc_html_e( 'Delete all access rules and settings from the database when the plugin is deleted', 'qaiyo-access-manager' ); ?></span>
				</label>
				<p class="wpam-hint" style="margin-top: 8px;">
					<?php esc_html_e( 'If unchecked (default), your rules are preserved so they are restored if you reinstall the plugin.', 'qaiyo-access-manager' ); ?>
				</p>
			</div>
		</div>
		<?php
	}

	/**
	 * Render the role checkbox grid + quick actions for an item card.
	 * Shared by the Plugins and Content Types tabs.
	 *
	 * @param array  $roles    Editable roles (slug => role data).
	 * @param array  $selected Currently checked role slugs.
	 * @param string $target   Item key (plugin file or post type) for data-target.
	 */
	private function render_role_grid( $roles, $selected, $target ) {
		?>
		<div class="wpam-roles-grid">
			<?php foreach ( $roles as $role_slug => $role_data ) : ?>
				<label class="wpam-role-checkbox">
					<input type="checkbox" class="wpam-role-cb"
						   data-target="<?php echo esc_attr( $target ); ?>"
						   value="<?php echo esc_attr( $role_slug ); ?>"
						   <?php checked( in_array( $role_slug, $selected, true ) ); ?> />
					<span class="wpam-role-name"><?php echo esc_html( translate_user_role( $role_data['name'] ) ); ?></span>
				</label>
			<?php endforeach; ?>
		</div>
		<div class="wpam-quick-actions">
			<button type="button" class="button button-small wpam-select-all-roles"><?php esc_html_e( 'Select all', 'qaiyo-access-manager' ); ?></button>
			<button type="button" class="button button-small wpam-deselect-all-roles"><?php esc_html_e( 'Deselect all', 'qaiyo-access-manager' ); ?></button>
		</div>
		<?php
	}

	/**
	 * Render the user-level override section (search + current overrides) for an
	 * item card. Shared by the Plugins and Content Types tabs.
	 *
	 * @param array $users Override rule: { allowed: int[], denied: int[] }.
	 */
	private function render_user_override_section( $users ) {
		?>
		<div class="wpam-section wpam-user-section">
			<h4><?php esc_html_e( 'User-level override', 'qaiyo-access-manager' ); ?></h4>
			<p class="wpam-hint"><?php esc_html_e( 'Individual allow or deny that overrides role-based rules. Administrators cannot be listed.', 'qaiyo-access-manager' ); ?></p>
			<div class="wpam-user-search-wrap">
				<input type="text" class="wpam-user-search" placeholder="<?php esc_attr_e( 'Search user (name, email, login)...', 'qaiyo-access-manager' ); ?>" autocomplete="off" />
				<div class="wpam-user-search-results"></div>
			</div>
			<div class="wpam-user-rules-list"
				 data-allowed="<?php echo esc_attr( wp_json_encode( $users['allowed'] ?? array() ) ); ?>"
				 data-denied="<?php echo esc_attr( wp_json_encode( $users['denied'] ?? array() ) ); ?>">
				<?php
				$all_user_ids = array_merge( $users['allowed'] ?? array(), $users['denied'] ?? array() );
				foreach ( $all_user_ids as $uid ) :
					$u = get_userdata( $uid );
					if ( ! $u ) {
						continue;
					}
					$is_allowed = in_array( $uid, $users['allowed'] ?? array(), true );
				?>
					<div class="wpam-user-rule-row" data-user-id="<?php echo esc_attr( $uid ); ?>">
						<span class="wpam-user-rule-info">
							<strong><?php echo esc_html( $u->display_name ); ?></strong>
							<span class="wpam-user-rule-meta"><?php echo esc_html( $u->user_email . ' — ' . implode( ', ', $u->roles ) ); ?></span>
						</span>
						<select class="wpam-user-rule-type">
							<option value="allowed" <?php selected( $is_allowed ); ?>><?php esc_html_e( 'Allowed', 'qaiyo-access-manager' ); ?></option>
							<option value="denied" <?php selected( ! $is_allowed ); ?>><?php esc_html_e( 'Denied', 'qaiyo-access-manager' ); ?></option>
						</select>
						<button type="button" class="button button-small wpam-user-rule-remove" title="<?php esc_attr_e( 'Remove', 'qaiyo-access-manager' ); ?>">&times;</button>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}

}
